# Changelog

All notable changes to `@iroha/iroha-js` are documented in this file.

## [Unreleased]

- Hardened Kotodama compiler result normalization against malformed or hostile
  native/service output. Successful manifests, recursive entrypoint schemas,
  triggers, localization/provenance metadata, and source-map/budget sidecars
  now use exact bounded V1 field contracts with cross-sidecar identity checks;
  accessors, sparse byte arrays, unsafe integers, retired `Amount`/`U128`
  leaves, and inconsistent parameter/return schemas fail closed. TypeScript
  declarations now expose the canonical `Int`/`Decimal`/`Quantity` leaf set,
  and the exact `Norito` runtime namespace includes `validateNoritoFrame`.
  Remote compilation now has a 30-second total deadline (bounded to two
  minutes when overridden), supports caller cancellation without trusting
  instance accessors, and races uncooperative Fetch/body readers while
  deterministically releasing listeners, timers, and streams. Its complete
  browser export bundles to 43,384 bytes (42.4 KiB, six modules, zero
  Node-only inputs or global `Buffer` assignments) under a 43 KiB gate.
- Rebased only the complete Node Torii bundle ceiling to 840 KiB after the
  pinned-esbuild security-hardening baseline reached exactly 852,966 bytes.
  The gate retains 7,194 bytes (0.84%) of headroom, while regression tests keep
  every browser ceiling unchanged and require all browser bundles to exclude
  Node-only inputs and global `Buffer` shims.
- Made native-host publication repeatable on Windows and fail closed across
  replacement failures. The publisher now locks the destination, verifies and
  probes a staged addon for the required Norito and Kotodama exports, moves an
  existing binary/checksum pair aside before replacement, publishes the new
  checksum manifest last, re-verifies the public pair, and restores the exact
  prior state while cleaning transaction artifacts on failure. Publication is
  now also durable across hard process termination: a versioned append-only
  journal, fsynced files and directory entries, exact old/new component
  inventories, and lock-held startup recovery resolve every replacement phase
  without guessing. Ambiguous, duplicated, missing, symlinked, or tampered
  recovery artifacts are preserved and rejected. Distribution/native locking
  now fingerprints the exact owner file, rechecks ownership before destructive
  phases, and atomically quarantines stale candidates so a replacement lock is
  never unlinked through a stale-lock time-of-check/time-of-use race.
- Replaced lossy Kotodama compiler exceptions with a discriminated asynchronous
  result. Node and browser-service compilation now preserve the canonical Rust
  diagnostic fields and UTF-8 byte spans, validate artifact/manifest/sidecar
  integrity on success, and bound compiler-service success and error bodies
  while reading them.
- Made the registry artifact independently consumable: NodeNext declaration
  targets and public subpath type exports are verified from a clean packed
  layout, registry recipes are restricted to clean-install portable examples,
  and native-only workflows are explicitly source-checkout scoped. Portable
  Node Ed25519 key generation/public-key derivation now use a native-equivalent
  Node-crypto fallback when the host binary is absent while preserving
  fail-closed behavior for present-but-unverified binaries. Shipped account
  examples are curve-valid canonical I105 literals and are regression-scanned.
- Fixed the built-in browser Connect approval handoff: browser Connect verifies
  the `{accountId, walletPublicKey, signature}` proof, while the Nexus facade
  projects the account and derives its Ed25519 controller instead of treating
  the X25519 `walletPublicKey` as a transaction key. Verified approvals are now
  returned as detached per-consumer snapshots, and a second approval frame
  closes the session without replacing the first identity. Submissions using
  `{wait: true, signal}` enforce intrinsic cancellation before dispatch and
  around injected waiters, require a wait capability before submission, capture
  extension callbacks with their original owners, hard-bound response bodies
  and asynchronous callbacks, and expose immutable error classification plus
  submission-state/hash context on failures. Status iterables are raw-entry
  bounded and acquired once.
- Made `build:dist` concurrency-safe and content-idempotent: explicit builds
  stage and validate the complete ESM tree under an inter-process lock, then
  replace `dist` only when its content changed, with stale-lock recovery,
  rollback to the last good tree after interrupted publication, and a shared
  reader lock for packaging. Consuming `file:` installs no longer run a mutating
  `prepare` hook; release gates now build first and verify the exact fresh tree
  through source/dist parity, safe tarball inspection, clean installation, and
  public/subpath imports.
- Added fail-closed proof-carrying deployed-contract submission. Callers now
  provide independently trusted ledger code and full-artifact identities;
  Torii simulation, fetched bytes, derived/proved bytecode, gas, entrypoint,
  payload, and proof/verifying-key backends are bound before signing. The new
  browser-safe `computeIvmArtifactHashes` helper and `./ivm-artifact` subpath
  compute both identities and ship standalone strict-DOM declarations without
  ambient Node types. Artifacts are capped at 4 MiB before allocation and
  SharedArrayBuffer-backed inputs are rejected, while genuine cross-realm
  ArrayBuffers remain supported. Code-byte, simulation, derivation, and proof
  responses now enforce declared and streamed endpoint-specific byte caps
  before fatal UTF-8 decoding and strict JSON parsing. Validation-fee policy
  verification now uses strict
  uncofactored Ed25519 verification, rejects duplicate governance keyset ids,
  bounds adversarial inputs before allocation, and fails closed on unaudited
  overlay instruction families. IVM proof polling validates options before job
  creation and best-effort cancels failed or aborted jobs.

## [0.0.3] - 2026-07-11

- Hardened Nexus wallet-signing boundaries: signables are now copied and
  independently validated as canonical `Transfer::Asset` payloads before any
  signer callback, Connect and transfer alias conflicts fail closed, polling
  options are validated before Torii submission, and non-canonical scaled
  numeric archives with trailing zeros are rejected. The exported
  `validateBrowserTransferSignable` helper and executable Nexus recipe smoke
  test expose and lock the same validation contract for integrators.
- Made the complete public `./browser` aggregate bundle-safe without global
  shims: browser Buffer edges resolve through the declared `buffer` dependency,
  while browser-safe modules import a package-local crypto adapter that maps to
  streaming `@noble/hashes` SHA-256 and securely chunked Web Crypto entropy;
  Node consumers retain native crypto semantics. The `./canonical-request`
  subpath now supports secure default nonce generation in browser builds and
  ships standalone strict-DOM declarations without ambient Node types.
  Release checks bundle both that subpath and the full browser namespace,
  reject Node-only graph inputs, and enforce measured 75 KiB and 300 KiB
  production bundle ceilings respectively.

- Hardened Nexus custom-codec boundaries with descriptor snapshots, exact and
  recomputed payload hashes, independently finalized canonical signed bytes,
  conflict-checked local/Torii aliases, and pre-copy byte limits. Release
  checks now pin `esbuild`, fail closed when it is unavailable, and enforce
  measured Torii, browser transaction-codec, and browser Nexus-app bundle
  ceilings. The `./nexus-app` graph no longer imports Node/native modules in a
  browser build; its default codec and bounded Torii submit/status transport
  are browser-safe and covered by runtime and adversarial tests. Its packed
  declarations also compile for strict DOM consumers without ambient Node
  types, using the runtime `buffer` package's self-contained type export.
- Added the browser-safe `@iroha/iroha-js/transaction-codec` subpath for
  canonical transparent Ed25519 transfer payloads, external-signing prehashes,
  verified signed-transaction finalization, and compact pipeline hashes. The
  codec rejects contradictory signer state, non-canonical Norito, and bounded
  metadata violations before producing submission bytes. Canonical metadata
  strings, pre-decode field limits, and the Rust 64-byte signed-numeric range
  are enforced before parsing or large-integer conversion. Browser and Node
  Ed25519 verification now match Rust strict verification, including exact
  uncofactored equations and mixed-torsion rejection.
- Added signed Torii alias-resolution ergonomics: `resolveAlias`,
  `resolveAliasByIndex`, and `lookupAliasesByAccount` now accept
  `canonicalAuth`, and `buildCanonicalJsonRequest` builds a signed JSON request
  from either private-key bytes or an async browser-wallet signer.
- `ToriiClient.callContract` now requires a `gasLimit` in the request payload so
  callers always supply the on-chain gas cap; typings, README docs, and test
  coverage reflect the stricter contract.【javascript/iroha_js/src/toriiClient.js:15360】【javascript/iroha_js/index.d.ts:4477】【javascript/iroha_js/test/toriiClient.test.js:13919】【javascript/iroha_js/test/integrationTorii.test.js:2701】【javascript/iroha_js/README.md:1909】
- Removed JS client helpers for legacy offline HTTP routes that Torii no longer
  mounts. `getOfflineReadiness()` is
  the supported readiness probe for `/v1/offline/readiness`.
- Constrained the JS SDK to the first-release surface: Connect WebSocket URLs no longer accept token
  query parameters, Torii health snapshots now only parse JSON responses, the `X-Iroha-API-Token`
  alias is no longer emitted, V1 telemetry counter aliases are dropped, and account address
  decoding rejects extension-flag headers. Tests and docs now reflect the first-release surface.
- Added `ToriiClient.iterateVerifyingKeys` and `iterateProverReports` plus
  iterator option whitelists so SoraFS/registry/prover paginators accept their
  filter fields alongside paging knobs; typings, README snippets, and Jest
  coverage close the remaining JS-04/JS-07 pagination gaps.【javascript/iroha_js/src/toriiClient.js:1181】【javascript/iroha_js/src/toriiClient.js:4671】【javascript/iroha_js/src/toriiClient.js:6949】【javascript/iroha_js/index.d.ts:5470】【javascript/iroha_js/test/toriiClient.test.js:761】【javascript/iroha_js/test/toriiClient.test.js:11493】【javascript/iroha_js/README.md:106】
- The JS SNS helpers now track the ledger-backed `/v1/sns/names...` Torii API.
  `createSnsGovernanceCase`, `exportSnsGovernanceCases`, and
  `iterateSnsGovernanceCases` are retained only as validation stubs that reject
  because Torii removed `/v1/sns/governance/cases`; README guidance, typings,
  and Jest coverage now point callers at inline governance hooks and the new
  namespace-aware SNS routes.【javascript/iroha_js/src/toriiClient.js:4121】【javascript/iroha_js/index.d.ts:6578】【javascript/iroha_js/test/toriiClient.test.js:18238】【javascript/iroha_js/README.md:3226】
- ISO bridge status normalization now constrains Torii responses to the
  expected `Pending`/`Accepted`/`Rejected` labels and validates `pacs002_code`
  against the standard `ACTC`/`ACSP`/`ACSC`/`ACWC`/`PDNG`/`RJCT` set so JS-06
  callers get deterministic errors when the bridge returns an unexpected
  state. Typings, README/docs snippets, and Jest coverage exercise the new
  validation paths.【javascript/iroha_js/src/toriiClient.js:7168】【javascript/iroha_js/index.d.ts:3600】【javascript/iroha_js/test/toriiClient.test.js:940】【javascript/iroha_js/README.md:1232】【docs/source/sdk/js/governance_iso_examples.md:79】
- `decodeI105AccountAddress` now enforces string inputs and surfaces a
  clear `TypeError` for non-string values, keeping JS-04 validation parity for
  I105 helpers and preventing accidental coercion when decoding selectors.
  Jest coverage guards the new behaviour.【javascript/iroha_js/src/address.js:1635】【javascript/iroha_js/test/address.test.js:482】
- Added optional SNS integration smoke coverage gated by
  `IROHA_TORII_INTEGRATION_SNS_SUFFIX`/`IROHA_TORII_INTEGRATION_SNS_SELECTOR`
  so JS-04/ADDR-5 adopters can validate suffix policies and registration
  payloads against live Torii deployments without bespoke scripts. README
  environment docs and integration assertions cover the new toggles.【javascript/iroha_js/test/integrationTorii.test.js:2988】【javascript/iroha_js/README.md:2015】
- Added `ToriiClient.submitIsoMessage`, which builds pacs.008/pacs.009 payloads
  from structured fields, applies pacs-specific `Content-Type` defaults, reuses
  a single `AbortSignal` across submission and polling, and optionally waits
  for a terminal bridge status. Typings, README/docs snippets, and Jest
  coverage keep the JS-06 advanced ISO bridge flow deterministic for CI and
  operators.【javascript/iroha_js/src/toriiClient.js:493】【javascript/iroha_js/index.d.ts:5420】【javascript/iroha_js/test/toriiClient.test.js:2876】【javascript/iroha_js/README.md:1243】【docs/source/sdk/js/governance_iso_examples.md:92】
- Hardened `ToriiClient.waitForTransactionStatus{,Typed}` by validating the
  polling options up front: the helper now requires the options payload to be a
  plain object, enforces non-negative `intervalMs`/`timeoutMs`, positive
  `maxAttempts`, and a functional `onStatus` callback while reusing the same
  guards inside `submitTransactionAndWait`. README snippets and Jest coverage
  document the stricter JS-04 validation so callers receive actionable
  `TypeError`s before any Torii request is issued.【javascript/iroha_js/src/toriiClient.js:1756】【javascript/iroha_js/test/toriiClient.test.js:2598】【javascript/iroha_js/README.md:148】
- Added `ToriiClient.submitDaBlob` together with the DA ingest builder, typings, README
  snippet, and Jest coverage so JS-04/DA-8 callers can mirror the
  `iroha da submit` payload (BLAKE3 digest, typed metadata, retention policy) directly from
  Node without shelling out to the CLI.【javascript/iroha_js/src/toriiClient.js:1163】【javascript/iroha_js/src/dataAvailability.js:22】【javascript/iroha_js/index.d.ts:4030】【javascript/iroha_js/README.md:770】【javascript/iroha_js/test/toriiClient.test.js:1408】
- Added `buildDaProofSummaryArtifact` and `emitDaProofSummaryArtifact` so DA-8 proof
  workflows can serialise PoR summaries into the same Norito JSON emitted by
  `iroha da prove-availability`, with README usage, typings, and Jest coverage to keep the
  CLI-compatible artefacts reproducible from JS automation.【javascript/iroha_js/src/dataAvailability.js:111】【javascript/iroha_js/index.d.ts:3273】【javascript/iroha_js/README.md:820】【javascript/iroha_js/test/dataAvailability.proof.test.js:1】
- Hardened the Torii iterable/list/query helpers to reject non-object options,
  raising a `TypeError` before any HTTP call and documenting the stricter
  contract with README + Jest coverage so JS-04 validation stays aligned with
  the Rust/Python SDKs.【javascript/iroha_js/src/toriiClient.js:4391】【javascript/iroha_js/test/toriiClient.test.js:4452】【javascript/iroha_js/README.md:1689】
- Hardened the SoraFS, data availability, and UAID ToriiClient helpers by
  routing them through a shared `_normalizeOptionsWithSignal` guard so malformed
  `options` payloads are rejected before hitting Torii, and added Jest coverage
  to exercise the new JS-04 validation paths across the registry, PoR, storage,
  DA ingest, and Space Directory surfaces.【javascript/iroha_js/src/toriiClient.js:889】【javascript/iroha_js/src/toriiClient.js:5320】【javascript/iroha_js/test/toriiClient.test.js:1872】
- `ToriiClient.getSorafsPinManifest` now treats `404 Not Found` as `null`
  so callers can distinguish between "missing" and "malformed" responses, and
  `getSorafsPinManifestTyped` raises an explicit error when Torii cannot locate
  the requested digest. README guidance and Jest coverage document the stricter
  behaviour to keep JS-04 validation aligned with the SoraFS rollout
  requirements.【javascript/iroha_js/src/toriiClient.js:1438】【javascript/iroha_js/test/toriiClient.test.js:1515】【javascript/iroha_js/README.md:903】
- Added `ToriiClient.getUaidPortfolio`, `getUaidBindings`, and `getUaidManifests`
  plus TypeScript definitions, README docs, and Jest coverage so the JS SDK
  mirrors the Nexus NX-16 UAID portfolio and Space Directory manifest APIs
  without bespoke JSON parsing. The helpers validate UAID literals, lifecycle
  metadata, and dataspace filters, keeping the new universal-account surfaces in
  lockstep with the Torii reference docs.【javascript/iroha_js/src/toriiClient.js:1234】【javascript/iroha_js/index.d.ts:3255】【javascript/iroha_js/README.md:818】【javascript/iroha_js/test/toriiClient.test.js:964】【docs/source/torii/portfolio_api.md:1】
- Added `ToriiClient.callContract` with typed request/response normalisation so
  Node.js clients can invoke `/v1/contracts/call` without hand-crafting JSON,
  keeping contract execution coverage aligned with the roadmap’s JS-04/JS-06
  goals.
- Added `ToriiClient.iterateConnectApps` along with cursor-aware pagination
  helpers, TypeScript definitions, README usage, and Jest coverage so Connect
  registry admins can stream `/v1/connect/app/apps` listings without manual
  `cursor` bookkeeping, advancing the roadmap’s JS-04 complex pagination
  deliverable.
- Added `ToriiClient.getExplorerAccountQr` with typed DTOs, TypeScript
  definitions, README usage, and Jest coverage so wallets and explorers can
  fetch share-ready QR payloads in canonical I105 form directly from Torii
  instead of reimplementing the renderer, progressing ADDR-6b’s SDK coverage
  goals.【javascript/iroha_js/src/toriiClient.js:1440】【javascript/iroha_js/index.d.ts:3513】【javascript/iroha_js/README.md:1538】【javascript/iroha_js/test/toriiClient.test.js:6650】
- Broadened the Dockerised integration smoke suite to cover asset re-mint
  flows, iterator-based queries, and an optional ISO `pacs.008` submission; the
  README now documents the new environment toggles and the CI workflow emits
  runtime/cache telemetry so JS-10’s “docs + tests + metrics” gate exercises
  more real-world scenarios.【javascript/iroha_js/test/integrationTorii.test.js:1】【javascript/iroha_js/README.md:1325】【.github/workflows/javascript-sdk.yml:56】
- Added an optional RBC sampling integration test driven by
  `IROHA_TORII_INTEGRATION_RBC_SAMPLE`; when set, the suite now calls
  `ToriiClient.sampleRbcChunks()` against the live node and validates the typed
  chunk proofs/audit paths so JS-10 coverage includes the RBC observability
  surface, and the README explains the new behaviour.【javascript/iroha_js/test/integrationTorii.test.js:1】【javascript/iroha_js/README.md:1325】
- Hardened `ToriiClient.createConnectSession`/`deleteConnectSession` by
  normalising `sid`, enforcing the 32-byte base64url/hex requirement, surfacing
  `extra` metadata, and rejecting malformed Torii responses so the Connect
  overlay helper satisfies the roadmap’s JS-04 validation goals. The README
  example now calls out the sid constraints plus returned URIs/tokens, and the
  TypeScript definitions/tests document the stricter behaviour.【javascript/iroha_js/src/toriiClient.js:2532】【javascript/iroha_js/README.md:1147】【javascript/iroha_js/test/toriiClient.test.js:5731】
- Added `generateConnectSid` and `createConnectSessionPreview` with README usage,
  TypeScript definitions, and Jest coverage so the JS SDK can mint session ids,
  derive deeplink URIs, and expose the Connect preview workflow called out in
  the roadmap’s JS-04 Connect deliverable.【javascript/iroha_js/src/connectSession.js:1】【javascript/iroha_js/index.d.ts:1295】【javascript/iroha_js/README.md:1140】【javascript/iroha_js/test/connectSession.test.js:1】
- Added `bootstrapConnectPreviewSession` to bundle the preview + Torii
  registration flow in one helper, with README docs, TypeScript declarations,
  and tests so JS SDK consumers can script the Connect preview setup without
  rewriting the session orchestration logic.【javascript/iroha_js/src/connectPreviewFlow.js:1】【javascript/iroha_js/src/index.js:1】【javascript/iroha_js/index.d.ts:1473】【javascript/iroha_js/README.md:1367】【javascript/iroha_js/test/connectPreviewFlow.test.js:1】
- Added normalised pipeline status helpers
  (`getTransactionStatus`, `getTransactionStatusTyped`,
  `waitForTransactionStatusTyped`, `submitTransactionAndWaitTyped`) with
  TypeScript definitions, README usage, and Jest coverage so JS-04 validation
  also covers the `/v1/pipeline/*` surfaces: the raw helper now enforces the
  canonical `kind`/`content.hash`/`status.kind` layout while the typed
  wrappers expose DTOs instead of forcing consumers to inspect Torii's JSON
  blobs.
- Added `getNetworkTimeNow` and `getNetworkTimeStatus` helpers (with TypeScript
  definitions, README usage, and tests) so the JS SDK can query the `/v1/time/*`
  endpoints and keep the NRPC/AND7 network-time diagnostics in lockstep with
  the Rust/Python clients.
- Normalized `ToriiClient.getHealth()` so it returns a typed `{status: string}`
  snapshot when Torii replies with JSON payloads, keeping the health telemetry
  surface aligned with JS-04 validation coverage.
- Normalised `ToriiClient.getBlock`/`listBlocks` responses into the typed
  `ToriiExplorerBlock` and `ToriiExplorerBlocksPage` DTOs (404 now yields `null`
  for `getBlock`), added TypeScript definitions/README docs, and extended the
  Jest suite so the explorer block endpoints enjoy the same JS-04 validation
  guarantees as the rest of the Torii query surface.
- Added `getSumeragiTelemetry`/`getSumeragiTelemetryTyped` to `ToriiClient`
  with typed availability/RBC/VRF snapshots, README guidance, and TypeScript
  definitions so JS SDK users can replay `/v1/sumeragi/telemetry` data as part
  of the JS-04/JS-07 roadmap telemetry coverage without bespoke parsing, and
  tightened `sampleRbcChunks` validation so block/hash/proof fields must be
  hex-encoded like the Rust/Python clients.
- Added `ToriiClient.listTelemetryPeersInfo` plus the corresponding DTOs,
  TypeScript declarations, README usage example, and unit tests so the JS SDK
  exposes the `/v1/telemetry/peers-info` surface that Rust/Python clients rely
  on for telemetry replay/peer analytics.
- Added `NoritoRpcClient` and the accompanying `NoritoRpcError`, TypeScript
  definitions, and tests so Node consumers can call the binary Norito-RPC
  surface with first-class helpers instead of wiring bespoke fetch logic.
- Added the missing `ToriiClient.submitTransactionAndWait` helper so the
  runtime now matches the published TypeScript definitions, validating
  `hashHex` inputs and reusing the existing pipeline polling logic.
- Added `ToriiClient` helpers for Sumeragi telemetry endpoints
  (`getSumeragiPacemaker`, `getSumeragiQc`, `getSumeragiPhases`,
  `getSumeragiBlsKeys`, `getSumeragiLeader`, `getSumeragiCollectors`,
  `getSumeragiParams`) with README examples, TypeScript definitions, and tests
  so JS SDK consumers can inspect the same `/v1/sumeragi/*` diagnostics that
  Rust tooling relies on for roadmap JS-08 coverage.
- Hardened `listGovernanceInstances`/`listContractInstances` validation so
  `hashPrefix` must be hexadecimal and `order` is clamped to the Torii-supported
  values (`cid_asc`, `cid_desc`, `hash_asc`, `hash_desc`). The TypeScript
  definitions now encode the same order enum to keep JS-04 validation/typedef
  parity green.
- Added governance HTTP helpers (`governanceProposeDeployContract`,
  `governanceSubmitPlainBallot`, `governanceSubmitZkBallot`,
  `governanceSubmitZkBallotV1`, `governanceSubmitZkBallotProofV1`) with input
  validation, README snippets, and TypeScript definitions so the JS SDK covers
  the `/v1/gov/proposals/deploy-contract` and ballot DTOs described in
  `docs/source/governance_api.md`.
- Removed legacy `addressFormat` support from `ToriiClient.listAccounts`/`queryAccounts`;
  SDK account-list/query helpers are now canonical I105-only.
- Added runtime capability helpers to `ToriiClient`
  (`getNodeCapabilities`, `getRuntimeAbiActive`, `getRuntimeAbiHash`,
  `getRuntimeMetrics`, `listRuntimeUpgrades`) with README snippets, TypeScript
  definitions, and unit tests so JS-07 advanced endpoint coverage now includes
  the `/v1/node/capabilities` and `/v1/runtime/*` surfaces exposed by Torii.
- Added runtime upgrade transaction helpers
  (`proposeRuntimeUpgrade`, `activateRuntimeUpgrade`, `cancelRuntimeUpgrade`)
  so rollout automation can post manifests and fetch transaction skeletons
  directly from the JS SDK, complete with typed inputs, README examples, and
  Jest coverage.
- Added the missing `iterate*Query` TypeScript declarations
  (`iterateAccountsQuery`, `iterateDomainsQuery`,
  `iterateAssetDefinitionsQuery`, `iterateNftsQuery`,
  `iterateAccountAssetsQuery`, `iterateAccountTransactionsQuery`,
  `iterateAssetHoldersQuery`) so the typings now match the runtime
  implementation and close the remaining JS-04 validation/type gaps.
- Added shared Torii governance/query fixtures
  (`javascript/iroha_js/test/fixtures/torii_responses.json`) and migrated the
  `toriiClient` governance + iterable tests to those payloads so JS-04 parity
  checks rely on the same deterministic responses that Rust/Python SDKs use
  for ballot/proposal/council validation.
- Hardened `ToriiClient.listSumeragiEvidence` so responses are validated and
  normalised into the typed `SumeragiEvidenceRecord` structures, rejecting
  malformed fields and keeping runtime behaviour aligned with the published
  TypeScript definitions/tests.
- Validated alias resolution responses for `ToriiClient.resolveAlias` and
  `resolveAliasByIndex`, normalising payloads into the published
  `AliasResolutionDto` shape and rejecting malformed fields so JS-04 query
  parity remains strict across runtimes. Tests now assert both happy-path
  normalisation and failure diagnostics.
- Added `listSorafsPinManifests` to `ToriiClient` plus typed DTOs for the pin
  registry so SDK consumers can page `/v1/sorafs/pin` with status filters and
  attestation metadata, completing the registry listing coverage called out in
  the pin-registry plan.
- Added `listSorafsAliases` and `listSorafsReplicationOrders` to `ToriiClient`
  so the JS SDK can page the `/v1/sorafs/aliases` and `/v1/sorafs/replication`
  endpoints with typed attestation metadata, fulfilling the remaining JS-07
  coverage for the pin registry's observability APIs.
- Added `ToriiClient.iterateSorafsPinManifests`,
  `iterateSorafsAliases`, and `iterateSorafsReplicationOrders` with README
  snippets, TypeScript declarations, and Jest coverage so the offset iterator
  helper can stream the SoraFS registry endpoints without bespoke pagination,
  extending the JS-07 query wrapper work to the storage APIs.【javascript/iroha_js/src/toriiClient.js:681】【javascript/iroha_js/index.d.ts:3408】【javascript/iroha_js/test/toriiClient.test.js:760】【javascript/iroha_js/README.md:732】
- Tightened the Sumeragi telemetry helpers by normalising the
  `getSumeragiPacemaker`, `getSumeragiQc`, `getSumeragiPhases`,
  `getSumeragiBlsKeys`, `getSumeragiLeader`, `getSumeragiCollectors`, and
  `getSumeragiParams` responses (raising type errors on malformed telemetry)
  and corrected the `getSumeragiStatus` TypeScript declaration to reflect that
  it returns the raw Torii payload while `getSumeragiStatusTyped` provides the
  validated snapshot.

## [0.0.2] - 2026-01-27

- Added governance instruction support to native Norito helpers so
  `buildCastZkBallotInstruction`, `buildCastPlainBallotInstruction`,
  `buildEnactReferendumInstruction`, `buildFinalizeReferendumInstruction`, and
  `buildPersistCouncilForEpochInstruction` now round-trip through
  `noritoEncodeInstruction`.
- Updated the native build script to try an offline cargo build first and
  automatically retry online when dependencies are missing.
- Added release documentation automation script covering changelog/status/roadmap updates.
- Added opt-in Torii integration smoke tests and documentation for exercising ISO bridge, RBC sampling, and Connect endpoints from the JS SDK.
- Added `submitIsoPacs009` helper mirroring the new Torii `/v1/iso20022/pacs009` endpoint,
  updated recipes/README, and extended TypeScript definitions/tests so PvP funding legs can be
  submitted from the SDK alongside pacs.008 flows.

## [0.0.1] - 2024-01-01

- Initial preview release of the Norito/Torii JavaScript SDK.

<!--
Maintainer note: keep this changelog aligned with the versions published to npm.
Continue to follow the Keep a Changelog format with ISO-8601 dates.
-->
