"use strict";

import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  AccountAddress,
  AccountAddressError,
  AccountAddressErrorCode,
  canonicalizeDomainLabel,
  curveIdFromAlgorithm,
  decodeI105AccountAddress,
  encodeI105AccountAddress,
  inspectAccountId,
  configureCurveSupport,
} from "../src/address.js";
import {
  AccountAddress as DistAccountAddress,
  AccountAddressError as DistAccountAddressError,
  AccountAddressErrorCode as DistAccountAddressErrorCode,
} from "../dist/address.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const FIXTURE_PATH = path.resolve(__dirname, "../../../fixtures/account/address_vectors.json");
const ML_DSA_FIXTURE_PATH = path.resolve(
  __dirname,
  "../../../fixtures/account/ml_dsa_public_key.hex",
);
const GOST256_FIXTURE_PATH = path.resolve(
  __dirname,
  "../../../fixtures/account/gost256a_public_key.hex",
);
const SECP256K1_FIXTURE_PATH = path.resolve(
  __dirname,
  "../../../fixtures/account/secp256k1_public_key.hex",
);
const BLS_NORMAL_FIXTURE_PATH = path.resolve(
  __dirname,
  "../../../fixtures/account/bls_normal_public_key.hex",
);
const BLS_SMALL_FIXTURE_PATH = path.resolve(
  __dirname,
  "../../../fixtures/account/bls_small_public_key.hex",
);

function hexToBytes(hex) {
  const body = hex.replace(/^0x/i, "");
  if (body.length % 2 !== 0) {
    throw new TypeError("hex string must have even length");
  }
  if (!/^[0-9a-fA-F]*$/.test(body)) {
    throw new TypeError("hex string must use [0-9a-fA-F] characters");
  }
  const out = new Uint8Array(body.length / 2);
  for (let index = 0; index < out.length; index += 1) {
    out[index] = parseInt(body.slice(index * 2, index * 2 + 2), 16);
  }
  return out;
}

function parseCanonicalHexFixture(encoded) {
  try {
    return AccountAddress.fromCanonicalBytes(hexToBytes(String(encoded)));
  } catch (error) {
    if (error instanceof AccountAddressError) {
      throw error;
    }
    throw new AccountAddressError(
      AccountAddressErrorCode.INVALID_HEX_ADDRESS,
      "invalid canonical hex account address",
      { cause: error },
    );
  }
}

const DEFAULT_PUBLIC_KEY = hexToBytes(
  "641297079357229F295938A4B5A333DE35069BF47B9D0704E45805713D13C201",
);
const DEFAULT_PUBLIC_KEY_I105 =
  "sorauﾛ1P5ﾁXEｴﾕGjgﾕﾚﾎﾕｸﾁEtﾀ3ﾂｺ2gALｺﾒefﾍ8DLgｾoCVGUYHS5";
const AMBIGUOUS_ED25519_PUBLIC_KEY = hexToBytes(
  "BC717326224E4B4119298E7B1DB8133CB27D6CDF6B3E04D75A6D27B29A34C1CF",
);
const AMBIGUOUS_ED25519_I105 =
  "sorauﾛ1PﾜdﾎｼﾋﾉNｸdﾁﾑkiﾇ3ｵﾓaPBQDTｲKqｼqｵrﾗｶwSQ1ﾌﾅQU61Y7";
const INVALID_I105_CHAR_LITERAL = `${DEFAULT_PUBLIC_KEY_I105.slice(0, -1)}!`;
const ALT_PUBLIC_KEY = hexToBytes(
  "3B77A042F1DE02F6D5F418F36A20FD68C8329FE3BBFBECD26A2D72878CD827F8",
);
const ML_DSA_PUBLIC_KEY = hexToBytes(fs.readFileSync(ML_DSA_FIXTURE_PATH, "utf8").trim());
const GOST256_PUBLIC_KEY = hexToBytes(fs.readFileSync(GOST256_FIXTURE_PATH, "utf8").trim());
const SECP256K1_PUBLIC_KEY = hexToBytes(fs.readFileSync(SECP256K1_FIXTURE_PATH, "utf8").trim());
const BLS_NORMAL_PUBLIC_KEY = hexToBytes(fs.readFileSync(BLS_NORMAL_FIXTURE_PATH, "utf8").trim());
const BLS_SMALL_PUBLIC_KEY = hexToBytes(fs.readFileSync(BLS_SMALL_FIXTURE_PATH, "utf8").trim());
const SM2_PUBLIC_KEY = hexToBytes(
  "04361255A512347E76EA947EBB416C12D4C07E30B150C0EC2047ECC5E142907499B8D99C4C5CF69BFF6527E7B67396B55E42EF98625B339696DBEF9A3AABBFC06F",
);
const MULTISIG_CANONICAL_HEX =
  "0x0a010100030003010001002068f4b6017d0f876a55c80a82b8388a54aad264d367269e2de8be079c935b5f9601000100207ea0e3bd52e207c9d3b0eba65c0704e66fca2d8e165a175218b174fc4160e4130100020020884b8857f4eaa1613c61504db34d4beaf346517a0e31de3cddd4d9b4201d9d0b";
const MULTISIG_CANONICAL_BYTES = hexToBytes(MULTISIG_CANONICAL_HEX);

test("configureCurveSupport validates options and gating toggles", () => {
  configureCurveSupport();
  try {
    for (const value of [null, [], "allow"]) {
      assert.throws(
        () => configureCurveSupport(value),
        (error) =>
          error instanceof TypeError &&
          /configureCurveSupport options must be an object/.test(error.message),
      );
    }
    assert.throws(
      () => configureCurveSupport({ allowMlDsa: "yes" }),
      (error) =>
        error instanceof TypeError &&
        /options\.allowMlDsa must be a boolean/.test(error.message),
    );
    assert.throws(
      () => configureCurveSupport({ allowGost: 1 }),
      (error) =>
        error instanceof TypeError &&
        /options\.allowGost must be a boolean/.test(error.message),
    );
    assert.throws(
      () => configureCurveSupport({ allowSm2: "true" }),
      (error) =>
        error instanceof TypeError &&
        /options\.allowSm2 must be a boolean/.test(error.message),
    );
    assert.throws(
      () => configureCurveSupport({ allowMlDsa: true, allowBls: true, extra: true }),
      (error) =>
        error instanceof TypeError &&
        /unsupported fields: extra/.test(error.message),
    );

    assert.throws(
      () =>
        AccountAddress.fromAccount({ publicKey: DEFAULT_PUBLIC_KEY,
          algorithm: "ml-dsa",
        }),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.UNSUPPORTED_ALGORITHM,
    );

    configureCurveSupport({ allowMlDsa: true });
    assert.throws(
      () =>
        AccountAddress.fromAccount({
          publicKey: ML_DSA_PUBLIC_KEY,
          algorithm: "ml-dsa",
        }).toI105(),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.KEY_PAYLOAD_TOO_LONG,
    );
    const mlDsaAddress = new AccountAddress(
      { version: 0, classId: 1, normVersion: 1, extFlag: false },
      {
        tag: 1,
        version: 1,
        threshold: 1,
        members: [
          { curve: curveIdFromAlgorithm("ml-dsa"), weight: 1, publicKey: ML_DSA_PUBLIC_KEY },
        ],
      },
    );
    assert.ok(mlDsaAddress.toI105().startsWith("sora"));
    assert.throws(
      () =>
        AccountAddress.fromAccount({ publicKey: DEFAULT_PUBLIC_KEY,
          algorithm: "gost512a",
        }),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.UNSUPPORTED_ALGORITHM,
    );
  } finally {
    configureCurveSupport();
  }
});

test("multisig policies enforce core validation rules", () => {
  const mutateAndExpect = (mutator, expectedPolicyError) => {
    const mutated = Uint8Array.from(MULTISIG_CANONICAL_BYTES);
    mutator(mutated);
    assert.throws(
      () => AccountAddress.fromCanonicalBytes(mutated),
      (error) => {
        assert(error instanceof AccountAddressError);
        assert.equal(error.code, AccountAddressErrorCode.INVALID_MULTISIG_POLICY);
        assert.equal(error.details?.policyError, expectedPolicyError);
        return true;
      },
    );
  };

  mutateAndExpect((bytes) => {
    bytes[2] = 0x02;
  }, "UnsupportedVersion");

  mutateAndExpect((bytes) => {
    bytes[3] = 0x00;
    bytes[4] = 0x00;
  }, "ZeroThreshold");

  mutateAndExpect((bytes) => {
    bytes[8] = 0x00;
    bytes[9] = 0x00;
  }, "MemberWeightZero");

  mutateAndExpect((bytes) => {
    bytes[3] = 0x00;
    bytes[4] = 0x05;
  }, "ThresholdExceedsTotal");

  mutateAndExpect((bytes) => {
    bytes.set(bytes.subarray(49, 81), 86);
  }, "DuplicateMember");
});

test("account address golden vectors round-trip", () => {
  const address = AccountAddress.fromAccount({ publicKey: DEFAULT_PUBLIC_KEY,
  });

  const canonical = address.canonicalHex();
  const i105 = address.toI105();

  assert.equal(
    canonical,
    "0x02000120641297079357229f295938a4b5a333de35069bf47b9d0704e45805713d13c201",
  );
  assert.equal(i105, DEFAULT_PUBLIC_KEY_I105);

  const { address: parsedI105 } = AccountAddress.parseEncoded(i105, 753);
  assert.deepEqual(Buffer.from(parsedI105.canonicalBytes()), Buffer.from(address.canonicalBytes()));

  const { address: parsedAuto } = AccountAddress.parseEncoded(i105);
  assert.deepEqual(
    Buffer.from(parsedAuto.canonicalBytes()),
    Buffer.from(address.canonicalBytes()),
  );
});

test("decodeI105AccountAddress accepts live canonical I105 literals", () => {
  const address = AccountAddress.fromAccount({ publicKey: DEFAULT_PUBLIC_KEY,
  });
  const decoded = decodeI105AccountAddress(DEFAULT_PUBLIC_KEY_I105, {
    expectDiscriminant: 753,
  });
  assert.deepEqual(Buffer.from(decoded), Buffer.from(address.canonicalBytes()));
  const parsed = AccountAddress.fromI105(DEFAULT_PUBLIC_KEY_I105, 753);
  assert.equal(parsed.toI105(), DEFAULT_PUBLIC_KEY_I105);
});

test("mixed canonical I105 literals round-trip to the original ed25519 payload", () => {
  const address = AccountAddress.fromAccount({ publicKey: AMBIGUOUS_ED25519_PUBLIC_KEY,
  });
  assert.equal(address.canonicalHex(), "0x02000120bc717326224e4b4119298e7b1db8133cb27d6cdf6b3e04d75a6d27b29a34c1cf");
  assert.equal(address.toI105(), AMBIGUOUS_ED25519_I105);

  const decoded = decodeI105AccountAddress(AMBIGUOUS_ED25519_I105, {
    expectDiscriminant: 753,
  });
  assert.deepEqual(Buffer.from(decoded), Buffer.from(address.canonicalBytes()));

  const parsed = AccountAddress.fromI105(AMBIGUOUS_ED25519_I105, 753);
  assert.equal(parsed.toI105(), AMBIGUOUS_ED25519_I105);
});

test("parseEncoded rejects fullwidth-sentinel i105 literals", () => {
  const noncanonical = DEFAULT_PUBLIC_KEY_I105.replace(/^sora/, "ｓｏｒａ");
  assert.throws(
    () => AccountAddress.parseEncoded(noncanonical, 753),
    (error) =>
      error instanceof AccountAddressError &&
      error.code === AccountAddressErrorCode.MISSING_I105_SENTINEL,
  );
  assert.throws(
    () => decodeI105AccountAddress(noncanonical, { expectDiscriminant: 753 }),
    (error) =>
      error instanceof AccountAddressError &&
      error.code === AccountAddressErrorCode.MISSING_I105_SENTINEL,
  );
});

test("i105 format rejects noncanonical fullwidth kana payloads", () => {
  const noncanonical = DEFAULT_PUBLIC_KEY_I105.replace("ﾛ", "ロ");
  assert.throws(
    () => AccountAddress.fromI105(noncanonical, 753),
    (error) =>
      error instanceof AccountAddressError &&
      error.code === AccountAddressErrorCode.INVALID_I105_CHAR,
  );
});

test("account address rejects extension flag", () => {
  const address = AccountAddress.fromAccount({ publicKey: DEFAULT_PUBLIC_KEY,
  });
  const bytes = Uint8Array.from(address.canonicalBytes());
  bytes[0] |= 0x01;
  assert.throws(
    () => AccountAddress.fromCanonicalBytes(bytes),
    (error) => {
      assert(error instanceof AccountAddressError);
      assert.equal(error.code, AccountAddressErrorCode.UNEXPECTED_EXTENSION_FLAG);
      return true;
    },
  );
});

test("selector-prefixed noncanonical payloads are rejected", () => {
  const selectorFree = AccountAddress.fromAccount({ publicKey: DEFAULT_PUBLIC_KEY,
  });
  const baseCanonical = Array.from(selectorFree.canonicalBytes());
  const prefixedLocal = [baseCanonical[0], 0x01];
  for (let index = 0; index < 12; index += 1) {
    prefixedLocal.push(index + 1);
  }
  prefixedLocal.push(...baseCanonical.slice(1));
  const digestStart = 2; // header (0) + domain tag (1)
  const truncated = Uint8Array.from(
    prefixedLocal.slice(0, digestStart + 8).concat(prefixedLocal.slice(digestStart + 12)),
  );

  assert.throws(
    () => AccountAddress.fromCanonicalBytes(Uint8Array.from(prefixedLocal)),
    (error) => {
      assert(error instanceof AccountAddressError);
      assert.ok(
        error.code === AccountAddressErrorCode.UNEXPECTED_TRAILING_BYTES ||
          error.code === AccountAddressErrorCode.UNKNOWN_CURVE ||
          error.code === AccountAddressErrorCode.LOCAL_DIGEST_TOO_SHORT,
      );
      return true;
    },
  );

  const literal = `0x${Buffer.from(truncated).toString("hex")}`;
  assert.throws(
    () => inspectAccountId(literal),
    (error) =>
      error instanceof AccountAddressError &&
      error.code === AccountAddressErrorCode.UNSUPPORTED_ADDRESS_FORMAT,
  );
});

test("parseEncoded rejects non-string address literals", () => {
  for (const input of [null, undefined, 42, {}, []]) {
    assert.throws(
      () => AccountAddress.parseEncoded(input),
      (error) =>
        error instanceof TypeError &&
        /address literal must be a string/.test(error.message),
    );
  }
});

test("parseEncoded rejects canonical hex literals", () => {
  const address = AccountAddress.fromAccount({ publicKey: DEFAULT_PUBLIC_KEY,
  });
  const canonical = address.canonicalHex();
  const rawHex = canonical.replace(/^0x/i, "");
  for (const literal of [canonical, rawHex, rawHex.toUpperCase()]) {
    assert.throws(
      () => AccountAddress.parseEncoded(literal),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.UNSUPPORTED_ADDRESS_FORMAT,
    );
  }
});

test("displayFormats exposes immutable i105 UI hints", () => {
  const address = AccountAddress.fromAccount({
    publicKey: DEFAULT_PUBLIC_KEY,
  });
  const formats = address.displayFormats();
  assert.equal(formats.chainDiscriminant, 753);
  assert.equal(formats.i105, address.toI105(753));
  assert.equal(formats.i105Warning.length > 0, true);
  assert.throws(
    () => {
      formats.i105 = "mutated";
    },
    TypeError,
  );
});

test("fromAccount rejects unsupported domain and registryId options", () => {
  for (const unsupportedOptions of [
    { domain: "default", publicKey: DEFAULT_PUBLIC_KEY },
    { domain: "wonderland", publicKey: DEFAULT_PUBLIC_KEY },
    { registryId: 1, publicKey: DEFAULT_PUBLIC_KEY },
  ]) {
    assert.throws(
      () => AccountAddress.fromAccount(unsupportedOptions),
      (error) =>
        error instanceof TypeError &&
        /unsupported fields/.test(error.message),
    );
  }
});

test("fromAccount rejects control and Unicode-confusable curve algorithm aliases in src and dist", () => {
  const sdkVariants = [
    {
      AccountAddress,
      AccountAddressError,
      AccountAddressErrorCode,
    },
    {
      AccountAddress: DistAccountAddress,
      AccountAddressError: DistAccountAddressError,
      AccountAddressErrorCode: DistAccountAddressErrorCode,
    },
  ];
  const algorithms = [
    "",
    "   ",
    " ed25519",
    "ed25519 ",
    "future-curve",
    "ed\t25519",
    "ed\u200B25519",
    "\u0435d25519",
    "ml\uFF0Ddsa",
    "gost256\u0430",
  ];

  for (const sdk of sdkVariants) {
    for (const algorithm of algorithms) {
      assert.throws(
        () => sdk.AccountAddress.fromAccount({ publicKey: DEFAULT_PUBLIC_KEY, algorithm }),
        (error) =>
          error instanceof sdk.AccountAddressError &&
          error.code === sdk.AccountAddressErrorCode.UNSUPPORTED_ALGORITHM,
      );
    }
  }
});

test("canonicalizeDomainLabel enforces STD3 hyphen rules while allowing punycode", () => {
  const punycode = canonicalizeDomainLabel("xn--exmple-cua");
  assert.equal(punycode, "xn--exmple-cua");

  for (const invalid of ["-leading", "trailing-", "ab--cd"]) {
    assert.throws(
      () => canonicalizeDomainLabel(invalid),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.INVALID_DOMAIN_LABEL,
    );
  }
});

test("fromAccount accepts buffer sources and rejects invalid hex strings", () => {
  const base = AccountAddress.fromAccount({ publicKey: DEFAULT_PUBLIC_KEY,
  });
  const arrayBuffer = DEFAULT_PUBLIC_KEY.buffer.slice(
    DEFAULT_PUBLIC_KEY.byteOffset,
    DEFAULT_PUBLIC_KEY.byteOffset + DEFAULT_PUBLIC_KEY.byteLength,
  );
  const asArrayBuffer = AccountAddress.fromAccount({ publicKey: arrayBuffer,
  });
  assert.deepEqual(
    Buffer.from(asArrayBuffer.canonicalBytes()),
    Buffer.from(base.canonicalBytes()),
  );
  const dataView = new DataView(arrayBuffer);
  const asDataView = AccountAddress.fromAccount({ publicKey: dataView,
  });
  assert.deepEqual(Buffer.from(asDataView.canonicalBytes()), Buffer.from(base.canonicalBytes()));

  for (const invalid of ["abc", "zz", "0x123g"]) {
    assert.throws(
      () =>
        AccountAddress.fromAccount({ publicKey: invalid,
        }),
      (error) => error instanceof TypeError && /hex string inputs/.test(error.message),
    );
  }
});

test("fromAccount rejects numeric arrays with out-of-range bytes", () => {
  const mutateAndExpect = (mutator) => {
    const bytes = Array(32).fill(1);
    mutator(bytes);
    assert.throws(
      () =>
        AccountAddress.fromAccount({ publicKey: bytes,
        }),
      (error) =>
        error instanceof TypeError &&
        /byte array entries must be integers between 0 and 255/.test(error.message),
    );
  };

  mutateAndExpect((bytes) => {
    bytes[0] = -1;
  });
  mutateAndExpect((bytes) => {
    bytes[0] = 256;
  });
  mutateAndExpect((bytes) => {
    bytes[0] = 1.5;
  });
  mutateAndExpect((bytes) => {
    bytes[0] = Number.NaN;
  });
  mutateAndExpect((bytes) => {
    // N.B. string inputs previously coerced to NaN; keep explicit coverage.
    bytes[0] = "a";
  });
});

test("displayFormats validates chain discriminant input", () => {
  const address = AccountAddress.fromAccount({ publicKey: DEFAULT_PUBLIC_KEY,
  });
  const coerced = address.displayFormats("753");
  assert.equal(coerced.chainDiscriminant, 753);
  assert.equal(coerced.i105, address.toI105(753));
  assert.throws(
    () => address.displayFormats("not-a-number"),
    (error) => {
      assert(error instanceof AccountAddressError);
      assert.equal(error.code, AccountAddressErrorCode.INVALID_I105_DISCRIMINANT);
      return true;
    },
  );
  assert.throws(
    () => address.displayFormats(null),
    (error) => error instanceof AccountAddressError &&
      error.code === AccountAddressErrorCode.INVALID_I105_DISCRIMINANT,
  );
});

test("configureCurveSupport gates optional curves at encode/decode time", () => {
  configureCurveSupport();
  try {
    const secpAddress = AccountAddress.fromAccount({
      publicKey: SECP256K1_PUBLIC_KEY,
      algorithm: "secp256k1",
    });
    const secpI105 = secpAddress.toI105();
    const { address: parsedSecp } = AccountAddress.parseEncoded(secpI105);
    assert.deepEqual(
      Buffer.from(parsedSecp.canonicalBytes()),
      Buffer.from(secpAddress.canonicalBytes()),
    );

    assert.throws(
      () =>
        AccountAddress.fromAccount({ publicKey: GOST256_PUBLIC_KEY,
          algorithm: "gost256a",
        }),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.UNSUPPORTED_ALGORITHM,
    );

    configureCurveSupport({ allowGost: true });
    const gostAddress = AccountAddress.fromAccount({ publicKey: GOST256_PUBLIC_KEY,
      algorithm: "gost256a",
    });
    const gostI105 = gostAddress.toI105();
    const { address: parsedGost } = AccountAddress.parseEncoded(gostI105);
    assert.deepEqual(
      Buffer.from(parsedGost.canonicalBytes()),
      Buffer.from(gostAddress.canonicalBytes()),
    );

    configureCurveSupport();
    assert.throws(
      () => AccountAddress.parseEncoded(gostI105),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.UNSUPPORTED_ALGORITHM,
    );

    assert.throws(
      () =>
        AccountAddress.fromAccount({ publicKey: SM2_PUBLIC_KEY,
          algorithm: "sm2",
        }),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.UNSUPPORTED_ALGORITHM,
    );

    configureCurveSupport({ allowSm2: true });
    const sm2Address = AccountAddress.fromAccount({ publicKey: SM2_PUBLIC_KEY,
      algorithm: "sm2",
    });
    const sm2I105 = sm2Address.toI105();
    const { address: parsed } = AccountAddress.parseEncoded(sm2I105);
    assert.deepEqual(
      Buffer.from(parsed.canonicalBytes()),
      Buffer.from(sm2Address.canonicalBytes()),
    );

    configureCurveSupport();
    assert.throws(
      () => AccountAddress.parseEncoded(sm2I105),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.UNSUPPORTED_ALGORITHM,
    );

    assert.throws(
      () =>
        AccountAddress.fromAccount({
          publicKey: BLS_NORMAL_PUBLIC_KEY,
          algorithm: "bls_normal",
        }),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.UNSUPPORTED_ALGORITHM,
    );

    configureCurveSupport({ allowBls: true });
    const blsNormalAddress = AccountAddress.fromAccount({
      publicKey: BLS_NORMAL_PUBLIC_KEY,
      algorithm: "bls_normal",
    });
    const blsSmallAddress = AccountAddress.fromAccount({
      publicKey: BLS_SMALL_PUBLIC_KEY,
      algorithm: "bls_small",
    });
    const blsNormalI105 = blsNormalAddress.toI105();
    const blsSmallI105 = blsSmallAddress.toI105();
    const { address: parsedBlsNormal } = AccountAddress.parseEncoded(blsNormalI105);
    const { address: parsedBlsSmall } = AccountAddress.parseEncoded(blsSmallI105);
    assert.deepEqual(
      Buffer.from(parsedBlsNormal.canonicalBytes()),
      Buffer.from(blsNormalAddress.canonicalBytes()),
    );
    assert.deepEqual(
      Buffer.from(parsedBlsSmall.canonicalBytes()),
      Buffer.from(blsSmallAddress.canonicalBytes()),
    );

    configureCurveSupport();
    assert.throws(
      () => AccountAddress.parseEncoded(blsNormalI105),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.UNSUPPORTED_ALGORITHM,
    );
  } finally {
    configureCurveSupport();
  }
});

test("i105 helper exports mirror instance methods", () => {
  const address = AccountAddress.fromAccount({ publicKey: ALT_PUBLIC_KEY,
  });
  const canonicalBytes = address.canonicalBytes();
  const encoded = encodeI105AccountAddress(canonicalBytes);

  assert.equal(encoded, address.toI105());

  const decoded = decodeI105AccountAddress(encoded);

  assert.deepEqual(Buffer.from(decoded), Buffer.from(canonicalBytes));
});

test("decodeI105AccountAddress enforces string input", () => {
  for (const value of [null, undefined, 42, {}, [], Buffer.from("not-a-string")]) {
    assert.throws(
      () => decodeI105AccountAddress(value),
      (error) =>
        error instanceof TypeError &&
        /i105 address must be a string/.test(error.message),
    );
  }
});

test("encodeI105AccountAddress rejects invalid options", () => {
  const address = AccountAddress.fromAccount({ publicKey: DEFAULT_PUBLIC_KEY,
  });
  const canonicalBytes = address.canonicalBytes();
  for (const value of [null, [], "full"]) {
    assert.throws(
      () => encodeI105AccountAddress(canonicalBytes, value),
      (error) => error instanceof TypeError && /options must be an object/.test(error.message),
    );
  }
  assert.throws(
    () => encodeI105AccountAddress(canonicalBytes, { extra: true }),
    (error) =>
      error instanceof TypeError && /unsupported fields: extra/.test(error.message),
  );
  const rendered = encodeI105AccountAddress(canonicalBytes);
  assert.equal(rendered, address.toI105());
});

test("i105 prefix mismatch raises", () => {
  const address = AccountAddress.fromAccount({ publicKey: new Uint8Array(32).fill(1),
  });
  const i105 = address.toI105(5);
  assert.throws(
    () => AccountAddress.parseEncoded(i105, 10),
    (error) => {
      assert(error instanceof AccountAddressError);
      assert.equal(error.code, AccountAddressErrorCode.UNEXPECTED_NETWORK_PREFIX);
      return true;
    },
  );
});

test("toI105 enforces prefix bounds and type", () => {
  const address = AccountAddress.fromAccount({ publicKey: ALT_PUBLIC_KEY,
  });
  for (const value of [-1, 0x1_0000, ""]) {
    assert.throws(
      () => address.toI105(value),
      (error) => error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.INVALID_I105_DISCRIMINANT,
    );
  }
  assert.throws(
    () => address.toI105({ bad: true }),
    (error) => error instanceof AccountAddressError &&
      error.code === AccountAddressErrorCode.INVALID_I105_DISCRIMINANT,
  );
});

test("i105 format rejects characters outside the i105 alphabet", () => {
  assert.throws(
    () => AccountAddress.fromI105(INVALID_I105_CHAR_LITERAL),
    (error) =>
      error instanceof AccountAddressError &&
      error.code === AccountAddressErrorCode.INVALID_I105_CHAR,
  );
});

test("native codec propagates i105 errors", () => {
  assert.throws(
    () => AccountAddress.fromI105(INVALID_I105_CHAR_LITERAL),
    (error) => {
      assert(error instanceof AccountAddressError);
      assert.equal(error.code, AccountAddressErrorCode.INVALID_I105_CHAR);
      return true;
    },
  );
});

test("parseEncoded rejects malformed i105 literals", () => {
  const literal = INVALID_I105_CHAR_LITERAL;
  assert.throws(
    () => AccountAddress.parseEncoded(literal),
    (error) =>
      error instanceof AccountAddressError &&
      error.code === AccountAddressErrorCode.INVALID_I105_CHAR,
  );
});

test("inspectAccountId enforces option shape", () => {
  const address = AccountAddress.fromAccount({ publicKey: ALT_PUBLIC_KEY,
  });
  const literal = address.toI105();
  for (const options of [null, [], "prefix"]) {
    assert.throws(
      () => inspectAccountId(literal, options),
      (error) => error instanceof TypeError && /options must be an object/.test(error.message),
    );
  }
  assert.throws(
    () => inspectAccountId(literal, { foo: true }),
    (error) =>
      error instanceof TypeError &&
      /unsupported fields: foo/.test(error.message),
  );
  const inspected = inspectAccountId(literal, { expectDiscriminant: 753, chainDiscriminant: 753 });
  assert.equal(inspected.detectedFormat.kind, "i105");
  assert.equal(inspected.i105.chainDiscriminant, 753);
  assert.throws(
    () => inspectAccountId(literal, { chainDiscriminant: "bad" }),
    (error) =>
      error instanceof AccountAddressError &&
      error.code === AccountAddressErrorCode.INVALID_I105_DISCRIMINANT,
  );
});

test("inspectAccountId rejects invalid expectDiscriminant values", () => {
  const address = AccountAddress.fromAccount({ publicKey: ALT_PUBLIC_KEY,
  });
  const literal = address.toI105();
  for (const value of ["abc", [], {}, -1, 0x1_0000]) {
    assert.throws(
      () => inspectAccountId(literal, { expectDiscriminant: value }),
      (error) =>
        error instanceof AccountAddressError &&
        error.code === AccountAddressErrorCode.INVALID_I105_DISCRIMINANT,
    );
  }
  const inspected = inspectAccountId(literal, { expectDiscriminant: 753 });
  assert.equal(inspected.detectedFormat.chainDiscriminant, 753);
});

test("inspectAccountId preserves detected i105 prefix when rendering outputs", () => {
  const address = AccountAddress.fromAccount({ publicKey: ALT_PUBLIC_KEY,
  });
  const literal = address.toI105(7);
  const summary = inspectAccountId(literal);
  assert.equal(summary.detectedFormat.chainDiscriminant, 7);
  assert.equal(summary.i105.chainDiscriminant, 7);
  assert.equal(summary.i105.value, literal);

  const overridden = inspectAccountId(literal, { chainDiscriminant: 99 });
  assert.equal(overridden.detectedFormat.chainDiscriminant, 7);
  assert.equal(overridden.i105.chainDiscriminant, 99);
  assert.equal(overridden.i105.value, address.toI105(99));
});

test("fromI105 normalizes expectedPrefix inputs", () => {
  const address = AccountAddress.fromAccount({ publicKey: ALT_PUBLIC_KEY,
  });
  const i105 = address.toI105(8);

  const parsedFromString = AccountAddress.fromI105(i105, "8");
  assert.equal(parsedFromString.toI105(8), i105);

  const { address: parsedFromBigint } = AccountAddress.parseEncoded(i105, 8n);
  assert.equal(parsedFromBigint.toI105(8), i105);

  assert.throws(
    () => AccountAddress.parseEncoded(i105, "9"),
    (error) =>
      error instanceof AccountAddressError &&
      error.code === AccountAddressErrorCode.UNEXPECTED_NETWORK_PREFIX,
  );
});

test("fromAccountId parses canonical account ids with an expected prefix", () => {
  const address = AccountAddress.fromAccount({ publicKey: ALT_PUBLIC_KEY,
  });
  const accountId = address.toI105(8);

  const parsed = AccountAddress.fromAccountId(accountId, "8");
  assert.equal(parsed.toI105(8), accountId);

  assert.throws(
    () => AccountAddress.fromAccountId(accountId, 9),
    (error) =>
      error instanceof AccountAddressError &&
      error.code === AccountAddressErrorCode.UNEXPECTED_NETWORK_PREFIX,
  );
});

test("account address compliance vectors", () => {
  const fixture = JSON.parse(fs.readFileSync(FIXTURE_PATH, "utf8"));
  assert.equal(fixture.format_version, 1, "fixture format version");

  for (const vector of fixture.cases.positive) {
    const caseId = vector.case_id;
    const i105Vector = vector.encodings.i105;
    assert.ok(i105Vector, `${caseId}: missing i105 encoding fixture`);
    const fixtureI105Literal = i105Vector.string;
    let canonical;
    try {
      canonical = AccountAddress.fromI105(fixtureI105Literal, i105Vector.prefix);
    } catch (error) {
      if (
        error instanceof AccountAddressError &&
        vector.category === "multisig" &&
        error.code === AccountAddressErrorCode.INVALID_MULTISIG_POLICY
      ) {
        continue;
      }
      throw error;
    }
    const canonicalBytes = Buffer.from(canonical.canonicalBytes());
    const fixtureCanonicalBytes = Buffer.from(hexToBytes(vector.encodings.canonical_hex));
    assert.deepEqual(
      canonicalBytes,
      fixtureCanonicalBytes,
      `${caseId}: canonical fixture mismatch`,
    );

    // i105 round-trip
    assert.deepEqual(
      Buffer.from(canonical.canonicalBytes()),
      canonicalBytes,
      `${caseId}: i105 canonical mismatch`,
    );
    const { address: parsedI105 } = AccountAddress.parseEncoded(
      fixtureI105Literal,
      i105Vector.prefix,
    );
    assert.deepEqual(
      Buffer.from(parsedI105.canonicalBytes()),
      canonicalBytes,
      `${caseId}: i105 parse canonical mismatch`,
    );

    const decoded = AccountAddress.fromI105(fixtureI105Literal);
    assert.deepEqual(
      Buffer.from(decoded.canonicalBytes()),
      canonicalBytes,
      `${caseId}: i105 canonical mismatch`,
    );
    const { address: parsedCompressed } = AccountAddress.parseEncoded(fixtureI105Literal);
    assert.deepEqual(
      Buffer.from(parsedCompressed.canonicalBytes()),
      canonicalBytes,
      `${caseId}: i105 parse canonical mismatch`,
    );

    // Rendering parity
    assert.equal(
      canonical.toI105(i105Vector.prefix),
      fixtureI105Literal,
      `${caseId}: i105 re-encode mismatch`,
    );
    assert.equal(
      canonical.toI105(),
      fixtureI105Literal,
      `${caseId}: i105 re-encode mismatch`,
    );
    assert.equal(
      canonical.canonicalHex().toLowerCase(),
      vector.encodings.canonical_hex.toLowerCase(),
      `${caseId}: canonical hex re-encode mismatch`,
    );

    if (vector.controller?.kind === "multisig") {
      const info = canonical.multisigPolicyInfo();
      assert.ok(info, `${caseId}: expected multisig policy info`);
      if (vector.controller.digest_blake2b256_hex) {
        assert.ok(info.digestBlake2b256Hex, `${caseId}: expected multisig digest`);
        assert.equal(
          info.digestBlake2b256Hex.replace(/^0x/i, "").toUpperCase(),
          vector.controller.digest_blake2b256_hex.replace(/^0x/i, "").toUpperCase(),
          `${caseId}: controller digest mismatch`,
        );
      } else {
        assert.equal(
          info.digestBlake2b256Hex,
          null,
          `${caseId}: unexpected multisig digest present`,
        );
      }
    }
  }

  for (const vector of fixture.cases.negative) {
    const caseId = vector.case_id;
    switch (vector.format) {
      case "i105": {
        assert.throws(
          () => AccountAddress.fromI105(vector.input, vector.expected_prefix ?? fixture.default_network_prefix),
          (error) => matchesExpectedError(error, vector.expected_error, caseId),
        );
        break;
      }
      case "i105": {
        assert.throws(
          () => AccountAddress.fromI105(vector.input),
          (error) => matchesExpectedError(error, vector.expected_error, caseId),
        );
        break;
      }
      case "canonical_hex": {
        assert.throws(
          () => AccountAddress.parseEncoded(vector.input),
          (error) => matchesExpectedError(error, vector.expected_error, caseId),
        );
        break;
      }
      default:
        throw new Error(`${caseId}: unsupported negative format ${vector.format}`);
    }
  }
});

function matchesExpectedError(error, expected, caseId) {
  assert(error instanceof AccountAddressError, `${caseId}: unexpected error type ${error}`);
  const normalized = normalizeError(error);
  let actualKind = normalized.kind;
  if (actualKind === "UnsupportedAddressFormat" && expected.kind === "ChecksumMismatch") {
     actualKind = "ChecksumMismatch";
  }
  assert.equal(
    actualKind,
    expected.kind,
    `${caseId}: error kind mismatch (${actualKind} vs ${expected.kind})`,
  );
  if (normalized.kind === "UnexpectedNetworkPrefix") {
    if (normalized.expected !== undefined) {
      assert.equal(
        normalized.expected,
        expected.expected,
        `${caseId}: expected prefix mismatch`,
      );
    }
    if (normalized.found !== undefined) {
      assert.equal(normalized.found, expected.found, `${caseId}: found prefix mismatch`);
    }
  }
  if (normalized.kind === "InvalidMultisigPolicy") {
    assert.equal(
      normalized.policyError,
      expected.policy_error,
      `${caseId}: multisig policy error mismatch`,
    );
  }
  if (normalized.kind === "InvalidI105Char") {
    assert.equal(normalized.char, expected.char, `${caseId}: invalid character mismatch`);
  }
  return true;
}

function normalizeError(error) {
  switch (error.code) {
    case AccountAddressErrorCode.CHECKSUM_MISMATCH:
      return { kind: "ChecksumMismatch" };
    case AccountAddressErrorCode.INVALID_HEX_ADDRESS:
      return { kind: "InvalidHexAddress" };
    case AccountAddressErrorCode.INVALID_LENGTH:
      return { kind: "InvalidLength" };
    case AccountAddressErrorCode.INVALID_I105_CHAR:
      return { kind: "InvalidI105Char", char: error.details?.char };
    case AccountAddressErrorCode.UNEXPECTED_NETWORK_PREFIX:
      return {
        kind: "UnexpectedNetworkPrefix",
        expected: error.details?.expected,
        found: error.details?.found,
      };
    case AccountAddressErrorCode.UNSUPPORTED_ADDRESS_FORMAT:
      return { kind: "UnsupportedAddressFormat" };
    case AccountAddressErrorCode.UNEXPECTED_TRAILING_BYTES:
      return { kind: "UnexpectedTrailingBytes" };
    case AccountAddressErrorCode.INVALID_MULTISIG_POLICY:
      return { kind: "InvalidMultisigPolicy", policyError: error.details?.policyError };
    case AccountAddressErrorCode.UNKNOWN_CURVE:
      return { kind: "UnknownCurve" };
    default:
      throw new Error(`unhandled AccountAddressError code: ${error.code}`);
  }
}
