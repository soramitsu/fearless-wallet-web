import { test as baseTest } from "node:test";
import assert from "node:assert/strict";
import { ed25519 } from "@noble/curves/ed25519";
import {
  hashInstructionBatch,
  hashSignedTransaction,
  hashSignedTransactionPayload,
  resignSignedTransaction,
  submitSignedTransaction,
  buildRegisterSnsNameTransaction,
  registerSnsNameViaConsensus,
  buildMintAndTransferTransaction,
  buildBurnAssetTransaction,
  buildBurnTriggerTransaction,
  buildRegisterDomainAndMintTransaction,
  buildRegisterAccountAndTransferTransaction,
  buildRegisterAssetDefinitionAndMintTransaction,
  buildRegisterAssetDefinitionMintAndTransferTransaction,
} from "../src/transaction.js";
import { ToriiClient } from "../src/toriiClient.js";
import { AccountAddress } from "../src/address.js";
import { makeNativeTest } from "./helpers/native.js";

const BASE_URL = "http://localhost:8080";
const PRIVATE_KEY = Buffer.alloc(32, 0x11);
const NEW_ACCOUNT_PRIVATE_KEY = Buffer.alloc(32, 0x22);
const AUTHORITY_ID_RAW = AccountAddress.fromAccount({
  publicKey: Buffer.from(ed25519.getPublicKey(PRIVATE_KEY)),
}).toI105();
const AUTHORITY_ID = i105FromEd25519AccountId(AUTHORITY_ID_RAW);
const AUTHORITY_ID_INPUT = i105FromEd25519AccountId(AUTHORITY_ID_RAW);
const NEW_ACCOUNT_ID_RAW = AccountAddress.fromAccount({
  publicKey: Buffer.from(ed25519.getPublicKey(NEW_ACCOUNT_PRIVATE_KEY)),
}).toI105();
const NEW_ACCOUNT_ID = i105FromEd25519AccountId(NEW_ACCOUNT_ID_RAW);
const NEW_ACCOUNT_ID_INPUT = i105FromEd25519AccountId(NEW_ACCOUNT_ID_RAW);
const ASSET_DEFINITION_ID = "62Fk4FPcMuLvW5QjDGNF2a4jAmjM";
const CANONICAL_ASSET_ID_INPUT = `${ASSET_DEFINITION_ID}#${AUTHORITY_ID}`;
const SECOND_CANONICAL_ASSET_ID_INPUT = `${ASSET_DEFINITION_ID}#${NEW_ACCOUNT_ID}`;
const ASSET_ID = CANONICAL_ASSET_ID_INPUT;
const ASSET_ID_INPUT = CANONICAL_ASSET_ID_INPUT;
const NODE_CAPABILITIES = {
  abi_version: 1,
  data_model_version: 1,
  crypto: {
    sm: {
      enabled: false,
      allowed_signing: [],
      acceleration: {
        scalar: true,
        neon_sm3: false,
        neon_sm4: false,
        policy: "scalar",
      },
    },
    curves: {
      registry_version: 1,
      allowed_curve_ids: [1],
      allowed_curve_bitmap: [],
    },
  },
};
const test = makeNativeTest(baseTest);

function i105FromEd25519AccountId(raw) {
  const trimmed = raw.trim();
  const atIndex = trimmed.lastIndexOf("@");
  if (atIndex === -1) {
    const { address } = AccountAddress.parseEncoded(trimmed);
    return address.toI105();
  }
  const signatory = trimmed.slice(0, atIndex).trim().toUpperCase();
  if (!signatory.startsWith("ED0120")) {
    throw new Error("expected ed25519 multihash signatory");
  }
  const publicKeyHex = signatory.slice(6);
  const publicKey = Buffer.from(publicKeyHex, "hex");
  return AccountAddress.fromAccount({ publicKey }).toI105();
}

function encodeAssetIdForKnownAccount(assetDefinitionId, accountId) {
  assert.equal(assetDefinitionId, ASSET_DEFINITION_ID);
  if (accountId === AUTHORITY_ID || accountId === AUTHORITY_ID_INPUT) {
    return CANONICAL_ASSET_ID_INPUT;
  }
  if (accountId === NEW_ACCOUNT_ID || accountId === NEW_ACCOUNT_ID_INPUT) {
    return SECOND_CANONICAL_ASSET_ID_INPUT;
  }
  throw new Error(`unexpected account id for test asset encoding: ${accountId}`);
}

test("hashSignedTransaction delegates to native binding and returns hex", () => {
  const input = Buffer.from([0xde, 0xad]);
  const fakeHash = Buffer.from([0x01, 0x02, 0x03, 0x04]);
  withNativeBinding({ hashSignedTransaction: () => fakeHash }, () => {
    const result = hashSignedTransaction(input);
    assert.equal(result, fakeHash.toString("hex"));
  });
});

test("hashSignedTransactionPayload delegates to the native payload hasher", () => {
  const input = Buffer.from([0xca, 0xfe]);
  const fakeHash = Buffer.alloc(32, 0x5a);
  withNativeBinding({ hashSignedTransactionPayload: () => fakeHash }, () => {
    assert.equal(hashSignedTransactionPayload(input), fakeHash.toString("hex"));
    assert.deepEqual(
      hashSignedTransactionPayload(input, { encoding: "buffer" }),
      fakeHash,
    );
  });
});

test("hashInstructionBatch serializes instructions and delegates to native", () => {
  const fakeHash = Buffer.alloc(32, 0x6b);
  const calls = [];
  withNativeBinding(
    {
      hashInstructionBatch: (instructions) => {
        calls.push(instructions);
        return fakeHash;
      },
    },
    () => {
      assert.equal(
        hashInstructionBatch([{ Log: { level: "INFO", msg: "bound" } }]),
        fakeHash.toString("hex"),
      );
      assert.deepEqual(
        hashInstructionBatch([JSON.stringify({ Fail: { message: "stop" } })], {
          encoding: "buffer",
        }),
        fakeHash,
      );
    },
  );
  assert.deepEqual(calls, [
    [JSON.stringify({ Log: { level: "INFO", msg: "bound" } })],
    [JSON.stringify({ Fail: { message: "stop" } })],
  ]);
});

test("submitSignedTransaction submits payload and polls status until terminal", async () => {
  const txBytes = Buffer.from([0xaa]);
  const signedBytes = Buffer.from([0xbb]);
  const hashBytes = Buffer.from([0x10, 0x11, 0x12, 0x13]);
  const submissionResponse = createResponse({
    status: 202,
    jsonData: { status: "Accepted" },
    headers: { "content-type": "application/json" },
  });
  const statusQueue = [
    createResponse({
      status: 202,
      jsonData: { status: "Accepted" },
      headers: { "content-type": "application/json" },
    }),
    createResponse({
      status: 200,
      jsonData: { status: "Pending" },
      headers: { "content-type": "application/json" },
    }),
    createResponse({
      status: 200,
      jsonData: { status: "Committed" },
      headers: { "content-type": "application/json" },
    }),
  ];
  const calls = [];
  const fetchImpl = async (url, init) => {
    calls.push({ url, init });
    if (url.endsWith("/v1/node/capabilities")) {
      return createResponse({
        status: 200,
        jsonData: NODE_CAPABILITIES,
        headers: { "content-type": "application/json" },
      });
    }
    if (url.endsWith("/v1/pipeline/transactions")) {
      assert.ok(Buffer.isBuffer(init.body));
      assert.deepEqual([...init.body.values()], [0x01, ...signedBytes.values()]);
      return submissionResponse;
    }
    return statusQueue.shift() ?? statusQueue[statusQueue.length - 1];
  };
  const client = new ToriiClient(BASE_URL, { fetchImpl });
  const binding = {
    hashSignedTransaction: () => hashBytes,
    signTransaction: (tx) => {
      assert.deepEqual([...tx.values()], [...txBytes.values()]);
      return signedBytes;
    },
  };

  const result = await withNativeBinding(binding, () =>
    submitSignedTransaction(client, txBytes, {
      waitForCommit: true,
      pollIntervalMs: 0,
      privateKey: Buffer.alloc(32, 0x01),
    }),
  );

  assert.equal(result.hash, hashBytes.toString("hex"));
  assert.deepEqual(result.status, { status: "Committed" });
  assert.equal(calls.length >= 3, true);
  const statusCalls = calls.filter((call) =>
    String(call.url).includes("/v1/pipeline/transactions/status"),
  );
  assert.equal(statusCalls.length, 3);
  assert.deepEqual(
    statusCalls.map((call) => new URL(call.url).searchParams.get("scope")),
    ["global", "global", "global"],
  );
});

test("submitSignedTransaction forwards explicit transaction status scope", async () => {
  const txBytes = Buffer.from([0xcc]);
  const signedBytes = Buffer.from([0xdd]);
  const binding = {
    hashSignedTransaction: () => Buffer.alloc(32, 0x66),
    signTransaction: () => signedBytes,
  };
  const calls = [];
  const fetchImpl = async (url, init) => {
    calls.push({ url, init });
    if (url.endsWith("/v1/node/capabilities")) {
      return createResponse({
        status: 200,
        jsonData: NODE_CAPABILITIES,
        headers: { "content-type": "application/json" },
      });
    }
    if (url.endsWith("/v1/pipeline/transactions")) {
      return createResponse({
        status: 202,
        jsonData: { status: "Accepted" },
        headers: { "content-type": "application/json" },
      });
    }
    return createResponse({
      status: 200,
      jsonData: { status: "Committed" },
      headers: { "content-type": "application/json" },
    });
  };
  const client = new ToriiClient(BASE_URL, { fetchImpl });

  await withNativeBinding(binding, () =>
    submitSignedTransaction(client, txBytes, {
      waitForCommit: true,
      pollIntervalMs: 0,
      privateKey: Buffer.alloc(32, 0x01),
      scope: "local",
    }),
  );

  const statusCall = calls.find((call) =>
    String(call.url).includes("/v1/pipeline/transactions/status"),
  );
  assert.ok(statusCall);
  assert.equal(new URL(statusCall.url).searchParams.get("scope"), "local");
});

test("submitSignedTransaction explicit status scope overrides client configuration", async () => {
  const txBytes = Buffer.from([0xd0]);
  const signedBytes = Buffer.from([0xd1]);
  const binding = {
    hashSignedTransaction: () => Buffer.alloc(32, 0x68),
    signTransaction: () => signedBytes,
  };
  const calls = [];
  const fetchImpl = async (url, init) => {
    calls.push({ url, init });
    if (url.endsWith("/v1/node/capabilities")) {
      return createResponse({
        status: 200,
        jsonData: NODE_CAPABILITIES,
        headers: { "content-type": "application/json" },
      });
    }
    if (url.endsWith("/v1/pipeline/transactions")) {
      return createResponse({
        status: 202,
        jsonData: { status: "Accepted" },
        headers: { "content-type": "application/json" },
      });
    }
    return createResponse({
      status: 200,
      jsonData: { status: "Committed" },
      headers: { "content-type": "application/json" },
    });
  };
  const client = new ToriiClient(BASE_URL, {
    fetchImpl,
    transactionStatusScope: "local",
  });

  await withNativeBinding(binding, () =>
    submitSignedTransaction(client, txBytes, {
      waitForCommit: true,
      pollIntervalMs: 0,
      privateKey: Buffer.alloc(32, 0x01),
      scope: "global",
    }),
  );

  const statusCall = calls.find((call) =>
    String(call.url).includes("/v1/pipeline/transactions/status"),
  );
  assert.ok(statusCall);
  assert.equal(new URL(statusCall.url).searchParams.get("scope"), "global");
});

test("submitSignedTransaction inherits client transaction status scope", async () => {
  const txBytes = Buffer.from([0xce]);
  const signedBytes = Buffer.from([0xcf]);
  const binding = {
    hashSignedTransaction: () => Buffer.alloc(32, 0x67),
    signTransaction: () => signedBytes,
  };
  const calls = [];
  const fetchImpl = async (url, init) => {
    calls.push({ url, init });
    if (url.endsWith("/v1/node/capabilities")) {
      return createResponse({
        status: 200,
        jsonData: NODE_CAPABILITIES,
        headers: { "content-type": "application/json" },
      });
    }
    if (url.endsWith("/v1/pipeline/transactions")) {
      return createResponse({
        status: 202,
        jsonData: { status: "Accepted" },
        headers: { "content-type": "application/json" },
      });
    }
    return createResponse({
      status: 200,
      jsonData: { status: "Committed" },
      headers: { "content-type": "application/json" },
    });
  };
  const client = new ToriiClient(BASE_URL, {
    fetchImpl,
    transactionStatusScope: "local",
  });

  await withNativeBinding(binding, () =>
    submitSignedTransaction(client, txBytes, {
      waitForCommit: true,
      pollIntervalMs: 0,
      privateKey: Buffer.alloc(32, 0x01),
    }),
  );

  const statusCall = calls.find((call) =>
    String(call.url).includes("/v1/pipeline/transactions/status"),
  );
  assert.ok(statusCall);
  assert.equal(new URL(statusCall.url).searchParams.get("scope"), "local");
});

test("submitSignedTransaction null status scope inherits client configuration", async () => {
  const txBytes = Buffer.from([0xd2]);
  const signedBytes = Buffer.from([0xd3]);
  const binding = {
    hashSignedTransaction: () => Buffer.alloc(32, 0x69),
    signTransaction: () => signedBytes,
  };
  const calls = [];
  const fetchImpl = async (url, init) => {
    calls.push({ url, init });
    if (url.endsWith("/v1/node/capabilities")) {
      return createResponse({
        status: 200,
        jsonData: NODE_CAPABILITIES,
        headers: { "content-type": "application/json" },
      });
    }
    if (url.endsWith("/v1/pipeline/transactions")) {
      return createResponse({
        status: 202,
        jsonData: { status: "Accepted" },
        headers: { "content-type": "application/json" },
      });
    }
    return createResponse({
      status: 200,
      jsonData: { status: "Committed" },
      headers: { "content-type": "application/json" },
    });
  };
  const client = new ToriiClient(BASE_URL, {
    fetchImpl,
    transactionStatusScope: "auto",
  });

  await withNativeBinding(binding, () =>
    submitSignedTransaction(client, txBytes, {
      waitForCommit: true,
      pollIntervalMs: 0,
      privateKey: Buffer.alloc(32, 0x01),
      scope: null,
    }),
  );

  const statusCall = calls.find((call) =>
    String(call.url).includes("/v1/pipeline/transactions/status"),
  );
  assert.ok(statusCall);
  assert.equal(new URL(statusCall.url).searchParams.get("scope"), "auto");
});

test("submitSignedTransaction times out when no terminal status", async () => {
  const txBytes = Buffer.from([0x99]);
  const binding = {
    hashSignedTransaction: () => Buffer.alloc(32, 0x42),
    signTransaction: () => txBytes,
  };
  const fetchImpl = async (url) => {
    if (url.endsWith("/v1/node/capabilities")) {
      return createResponse({
        status: 200,
        jsonData: NODE_CAPABILITIES,
        headers: { "content-type": "application/json" },
      });
    }
    return createResponse({
      status: 202,
      jsonData: { status: "Accepted" },
      headers: { "content-type": "application/json" },
    });
  };
  const client = new ToriiClient(BASE_URL, { fetchImpl });

  await withNativeBinding(binding, async () => {
    await assert.rejects(
      () =>
        submitSignedTransaction(client, txBytes, {
          waitForCommit: true,
          timeoutMs: 1,
          pollIntervalMs: 0,
          privateKey: Buffer.alloc(32, 0x02),
        }),
      /timed out/i,
    );
  });
});

test("submitSignedTransaction ignores state-only terminal fields", async () => {
  const txBytes = Buffer.from([0x44]);
  const signedBytes = Buffer.from([0x55]);
  const binding = {
    hashSignedTransaction: () => Buffer.alloc(32, 0x33),
    signTransaction: () => signedBytes,
  };
  const submissionResponse = createResponse({
    status: 202,
    jsonData: { status: "Accepted" },
    headers: { "content-type": "application/json" },
  });
  const statusPayload = {
    kind: "TransactionStatus",
    content: {
      hash: "00".repeat(32),
      status: {
        kind: "Committed",
        content: { state: "Committed" },
      },
    },
  };
  const fetchImpl = async (url) => {
    if (url.endsWith("/v1/node/capabilities")) {
      return createResponse({
        status: 200,
        jsonData: NODE_CAPABILITIES,
        headers: { "content-type": "application/json" },
      });
    }
    if (url.endsWith("/v1/pipeline/transactions")) {
      return submissionResponse;
    }
    return createResponse({
      status: 200,
      jsonData: statusPayload,
      headers: { "content-type": "application/json" },
    });
  };
  const client = new ToriiClient(BASE_URL, { fetchImpl });

  await withNativeBinding(binding, async () => {
    await assert.rejects(
      () =>
        submitSignedTransaction(client, txBytes, {
          waitForCommit: true,
          timeoutMs: 5,
          pollIntervalMs: 0,
          privateKey: Buffer.alloc(32, 0x03),
        }),
      /timed out/i,
    );
  });
});

test("resignSignedTransaction delegates to native binding", () => {
  const input = Buffer.from([0xde]);
  const key = Buffer.alloc(32, 0x11);
  const output = Buffer.from([0xef]);
  withNativeBinding(
    {
      signTransaction: (tx, pk) => {
        assert.deepEqual([...tx.values()], [...input.values()]);
        assert.deepEqual([...pk.values()], [...key.values()]);
        return output;
      },
    },
    () => {
      const result = resignSignedTransaction(input, key);
      assert.deepEqual(result, output);
    },
  );
});

baseTest("buildRegisterSnsNameTransaction yields RegisterSnsName instruction", () => {
  const captures = [];
  const request = {
    selector: { version: 1, suffix_id: 6647857470246403404, label: "is" },
    owner: AUTHORITY_ID_INPUT,
  };
  const result = withNativeBinding(
    {
      buildTransaction: (_chain, authority, instructions, metadata, _created, ttl, _nonce, pk) => {
        captures.push({
          authority,
          instructions: instructions.map((j) => JSON.parse(j)),
          metadata: JSON.parse(metadata),
          ttl,
          privateKey: Buffer.from(pk),
        });
        return {
          signed_transaction: Buffer.from([0x45]),
          hash: Buffer.alloc(32, 0x46),
        };
      },
    },
    () =>
      buildRegisterSnsNameTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        request,
        metadata: { purpose: "sns-name-registration" },
        ttlMs: 900_000,
        privateKey: PRIVATE_KEY,
      }),
  );

  assert.equal(result.hash.toString("hex"), "46".repeat(32));
  assert.equal(captures.length, 1);
  assert.equal(captures[0].authority, AUTHORITY_ID);
  assert.deepEqual(captures[0].instructions, [{ RegisterSnsName: request }]);
  assert.deepEqual(captures[0].metadata, { purpose: "sns-name-registration" });
  assert.equal(captures[0].ttl, 900_000);
  assert.deepEqual(captures[0].privateKey, PRIVATE_KEY);
});

baseTest("buildRegisterSnsNameTransaction rejects malformed registration requests", () => {
  for (const request of [null, undefined, [], "name.is"]) {
    assert.throws(
      () =>
        buildRegisterSnsNameTransaction({
          chainId: "test-chain",
          authority: AUTHORITY_ID_INPUT,
          request,
          privateKey: PRIVATE_KEY,
        }),
      /request must be a non-null object/,
    );
  }
});

baseTest("buildRegisterSnsNameTransaction ignores caller-supplied instructions", () => {
  const captures = [];
  withNativeBinding(
    {
      buildTransaction: (_chain, _authority, instructions) => {
        captures.push(instructions.map((j) => JSON.parse(j)));
        return {
          signed_transaction: Buffer.from([0x47]),
          hash: Buffer.alloc(32, 0x48),
        };
      },
    },
    () =>
      buildRegisterSnsNameTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        request: { selector: { label: "is" } },
        instructions: [{ Transfer: { Asset: { object: "999999" } } }],
        privateKey: PRIVATE_KEY,
      }),
  );

  assert.deepEqual(captures, [[{ RegisterSnsName: { selector: { label: "is" } } }]]);
});

baseTest("registerSnsNameViaConsensus returns PendingTimeout status", async () => {
  const request = {
    selector: { version: 1, suffix_id: 6647857470246403404, label: "is" },
    owner: AUTHORITY_ID_INPUT,
  };
  const signedTransaction = Buffer.from([0x51, 0x52]);
  const transactionHash = Buffer.alloc(32, 0x53);
  const submittedHash = Buffer.alloc(32, 0x54);
  const fetchImpl = async (url) => {
    if (url.endsWith("/v1/node/capabilities")) {
      return createResponse({
        status: 200,
        jsonData: NODE_CAPABILITIES,
        headers: { "content-type": "application/json" },
      });
    }
    return createResponse({
      status: 202,
      jsonData: { status: "Accepted" },
      headers: { "content-type": "application/json" },
    });
  };
  const client = new ToriiClient(BASE_URL, { fetchImpl });
  const result = await withNativeBinding(
    {
      buildTransaction: () => ({
        signed_transaction: signedTransaction,
        hash: transactionHash,
      }),
      hashSignedTransaction: () => submittedHash,
    },
    () =>
      registerSnsNameViaConsensus({
        client,
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        request,
        privateKey: PRIVATE_KEY,
        pollIntervalMs: 0,
        timeoutMs: 1,
        scope: "global",
      }),
  );

  assert.equal(result.hash, transactionHash.toString("hex"));
  assert.equal(result.submittedHash, submittedHash.toString("hex"));
  assert.deepEqual(result.submission, { status: "Accepted" });
  assert.equal(result.status.kind, "PendingTimeout");
  assert.deepEqual(result.status.lastStatus, { status: "Accepted" });
});

baseTest("registerSnsNameViaConsensus returns submitted hash when wait is disabled", async () => {
  const transactionHash = Buffer.alloc(32, 0x56);
  const submittedHash = Buffer.alloc(32, 0x57);
  const calls = [];
  const fetchImpl = async (url, init) => {
    calls.push({ url, init });
    if (url.endsWith("/v1/node/capabilities")) {
      return createResponse({
        status: 200,
        jsonData: NODE_CAPABILITIES,
        headers: { "content-type": "application/json" },
      });
    }
    assert.ok(url.endsWith("/v1/pipeline/transactions"));
    return createResponse({
      status: 202,
      jsonData: { status: "Accepted" },
      headers: { "content-type": "application/json" },
    });
  };
  const client = new ToriiClient(BASE_URL, { fetchImpl });

  const result = await withNativeBinding(
    {
      buildTransaction: () => ({
        signed_transaction: Buffer.from([0x58]),
        hash: transactionHash,
      }),
      hashSignedTransaction: () => submittedHash,
    },
    () =>
      registerSnsNameViaConsensus({
        client,
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        request: { selector: { label: "is" } },
        privateKey: PRIVATE_KEY,
        waitForCommit: false,
      }),
  );

  assert.equal(result.hash, transactionHash.toString("hex"));
  assert.equal(result.submittedHash, submittedHash.toString("hex"));
  assert.deepEqual(result.submission, { status: "Accepted" });
  assert.equal(result.status, null);
  assert.equal(
    calls.some((call) =>
      String(call.url).includes("/v1/pipeline/transactions/status"),
    ),
    false,
  );
});

baseTest("registerSnsNameViaConsensus validates client inputs and rethrows submit failures", async () => {
  const request = {
    selector: { version: 1, suffix_id: 6647857470246403404, label: "is" },
    owner: AUTHORITY_ID_INPUT,
  };

  await assert.rejects(
    () => registerSnsNameViaConsensus(null),
    /input must be an object/,
  );
  await assert.rejects(
    () => registerSnsNameViaConsensus({ request, privateKey: PRIVATE_KEY }),
    /client or toriiUrl is required/,
  );
  await assert.rejects(
    () =>
      registerSnsNameViaConsensus({
        client: { submitTransaction: async () => ({}) },
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        request,
        privateKey: PRIVATE_KEY,
      }),
    /client must be an instance of ToriiClient/,
  );

  const fetchImpl = async (url) => {
    if (url.endsWith("/v1/node/capabilities")) {
      return createResponse({
        status: 200,
        jsonData: NODE_CAPABILITIES,
        headers: { "content-type": "application/json" },
      });
    }
    return createResponse({
      status: 500,
      jsonData: { error: "submit rejected" },
      textBody: "submit rejected",
      headers: { "content-type": "application/json" },
    });
  };
  const client = new ToriiClient(BASE_URL, { fetchImpl });
  await withNativeBinding(
    {
      buildTransaction: () => ({
        signed_transaction: Buffer.from([0x61]),
        hash: Buffer.alloc(32, 0x62),
      }),
      hashSignedTransaction: () => Buffer.alloc(32, 0x63),
    },
    async () => {
      await assert.rejects(
        () =>
          registerSnsNameViaConsensus({
            client,
            chainId: "test-chain",
            authority: AUTHORITY_ID_INPUT,
            request,
            privateKey: PRIVATE_KEY,
            waitForCommit: false,
          }),
        /submit rejected|status 500|500/,
      );
    },
  );
});

test("buildMintAndTransferTransaction yields multi-instruction payload", () => {
  const captures = [];
  const result = withNativeBinding(
    {
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x01]),
          hash: Buffer.alloc(32, 0x22),
        };
      },
    },
    () =>
      buildMintAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        mint: { assetId: ASSET_ID_INPUT, quantity: "7" },
        transfer: {
          quantity: "3",
          destinationAccountId: AUTHORITY_ID_INPUT,
        },
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [
    { authority, instructions },
  ] = captures;
  assert.equal(authority, AUTHORITY_ID);
  assert.equal(instructions.length, 2);
  assert.equal(result.hash.length, 32);
  assert.deepEqual(instructions[0], {
    Mint: { Asset: { destination: ASSET_ID, object: "7" } },
  });
  assert.deepEqual(instructions[1], {
    Transfer: {
      Asset: {
        source: ASSET_ID,
        object: "3",
        destination: AUTHORITY_ID,
      },
    },
  });
});

test("buildBurnAssetTransaction yields single burn instruction", () => {
  const captures = [];
  withNativeBinding(
    {
      encodeAssetId: encodeAssetIdForKnownAccount,
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x12]),
          hash: Buffer.alloc(32, 0x24),
        };
      },
    },
    () =>
      buildBurnAssetTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetId: ASSET_ID_INPUT,
        quantity: "4",
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [{ authority, instructions }] = captures;
  assert.equal(authority, AUTHORITY_ID);
  assert.equal(instructions.length, 1);
  assert.deepEqual(instructions[0], {
    Burn: { Asset: { destination: ASSET_ID, object: "4" } },
  });
});

test("buildBurnTriggerTransaction yields single trigger burn instruction", () => {
  const captures = [];
  withNativeBinding(
    {
      encodeAssetId: encodeAssetIdForKnownAccount,
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x21]),
          hash: Buffer.alloc(32, 0x25),
        };
      },
    },
    () =>
      buildBurnTriggerTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        triggerId: "cleanup-trigger",
        repetitions: 1,
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [{ authority, instructions }] = captures;
  assert.equal(authority, AUTHORITY_ID);
  assert.equal(instructions.length, 1);
  assert.deepEqual(instructions[0], {
    Burn: { TriggerRepetitions: { destination: "cleanup-trigger", object: 1 } },
  });
});

test("buildMintAndTransferTransaction supports transfer arrays", () => {
  const captures = [];
  withNativeBinding(
    {
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x11]),
          hash: Buffer.alloc(32, 0x23),
        };
      },
    },
    () =>
      buildMintAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        mint: { assetId: ASSET_ID_INPUT, quantity: "9" },
        transfers: [
          { quantity: "5", destinationAccountId: AUTHORITY_ID_INPUT },
          {
            sourceAssetId: SECOND_CANONICAL_ASSET_ID_INPUT,
            quantity: "1",
            destinationAccountId: NEW_ACCOUNT_ID_INPUT,
          },
        ],
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [{ instructions }] = captures;
  assert.equal(instructions.length, 3);
  assert.deepEqual(instructions[0], {
    Mint: { Asset: { destination: ASSET_ID, object: "9" } },
  });
  assert.deepEqual(instructions[1], {
    Transfer: {
      Asset: {
        source: ASSET_ID,
        object: "5",
        destination: AUTHORITY_ID,
      },
    },
  });
  assert.deepEqual(instructions[2], {
    Transfer: {
      Asset: {
        source: SECOND_CANONICAL_ASSET_ID_INPUT,
        object: "1",
        destination: NEW_ACCOUNT_ID,
      },
    },
  });
});

test("buildMintAndTransferTransaction rejects both transfer and transfers", () => {
  assert.throws(
    () =>
      buildMintAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        mint: { assetId: ASSET_ID_INPUT, quantity: "4" },
        transfer: { quantity: "2", destinationAccountId: AUTHORITY_ID_INPUT },
        transfers: [],
        privateKey: PRIVATE_KEY,
      }),
    /provide either transfer or transfers/i,
  );
});

test("buildMintAndTransferTransaction requires at least one transfer", () => {
  assert.throws(
    () =>
      buildMintAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        mint: { assetId: ASSET_ID_INPUT, quantity: "4" },
        privateKey: PRIVATE_KEY,
      }),
    /transfer or transfers options are required/i,
  );
});

test("buildRegisterDomainAndMintTransaction expands registration and mint", () => {
  const captures = [];
  withNativeBinding(
    {
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x02]),
          hash: Buffer.alloc(32, 0x33),
        };
      },
    },
    () =>
      buildRegisterDomainAndMintTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        domain: { domainId: "garden_of_live_flowers.sora", metadata: { key: "value" } },
        mint: { assetId: ASSET_ID_INPUT, quantity: "10" },
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [{ instructions }] = captures;
  assert.equal(instructions.length, 2);
  assert.deepEqual(instructions[0], {
    Register: {
      Domain: {
        id: "garden_of_live_flowers.sora",
        logo: null,
        metadata: { key: "value" },
      },
    },
  });
  assert.deepEqual(instructions[1], {
    Mint: { Asset: { destination: ASSET_ID, object: "10" } },
  });
});

test("buildRegisterDomainAndMintTransaction supports mint arrays", () => {
  const captures = [];
  withNativeBinding(
    {
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x0A]),
          hash: Buffer.alloc(32, 0x99),
        };
      },
    },
    () =>
      buildRegisterDomainAndMintTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        domain: { domainId: "garden_of_live_flowers.sora" },
        mints: [
          { assetId: ASSET_ID_INPUT, quantity: "3" },
          { assetId: CANONICAL_ASSET_ID_INPUT, quantity: "1" },
        ],
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [{ instructions }] = captures;
  assert.equal(instructions.length, 3);
  assert.deepEqual(instructions[0].Register.Domain.id, "garden_of_live_flowers.sora");
  assert.deepEqual(instructions[1], {
    Mint: { Asset: { destination: ASSET_ID, object: "3" } },
  });
  assert.deepEqual(instructions[2], {
    Mint: {
      Asset: {
        destination: CANONICAL_ASSET_ID_INPUT,
        object: "1",
      },
    },
  });
});

test("buildRegisterDomainAndMintTransaction rejects both mint and mints", () => {
  assert.throws(
    () =>
      buildRegisterDomainAndMintTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        domain: { domainId: "garden_of_live_flowers.sora" },
        mint: { assetId: ASSET_ID_INPUT, quantity: "2" },
        mints: [],
        privateKey: PRIVATE_KEY,
      }),
    /provide either mint or mints/i,
  );
});

test("buildRegisterDomainAndMintTransaction enforces assetId in mints", () => {
  assert.throws(
    () =>
      buildRegisterDomainAndMintTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        domain: { domainId: "garden_of_live_flowers.sora" },
        mints: [{ quantity: "2" }],
        privateKey: PRIVATE_KEY,
      }),
    /mints\[0\]\.assetId must be a non-empty string/i,
  );
});

test("buildRegisterAccountAndTransferTransaction expands registration and transfer", () => {
  const captures = [];
  withNativeBinding(
    {
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x03]),
          hash: Buffer.alloc(32, 0x44),
        };
      },
    },
    () =>
      buildRegisterAccountAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        account: {
          accountId: NEW_ACCOUNT_ID_INPUT,
          metadata: { nickname: "alice" },
        },
        transfer: {
          sourceAssetId: ASSET_ID,
          quantity: "4",
          destinationAccountId: NEW_ACCOUNT_ID_INPUT,
        },
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [{ instructions }] = captures;
  assert.equal(instructions.length, 2);
  assert.deepEqual(instructions[0], {
    Register: {
      Account: {
        id: NEW_ACCOUNT_ID,
        label: null,
        uaid: null,
        opaque_ids: [],
        metadata: { nickname: "alice" },
      },
    },
  });
  assert.deepEqual(instructions[1], {
    Transfer: {
      Asset: {
        source: ASSET_ID,
        object: "4",
        destination: NEW_ACCOUNT_ID,
      },
    },
  });
});

test("buildRegisterAccountAndTransferTransaction supports transfer arrays", () => {
  const captures = [];
  const secondAccountIdRaw = AccountAddress.fromAccount({
    publicKey: Buffer.from(ed25519.getPublicKey(Buffer.alloc(32, 0x33))),
  }).toI105();
  const secondAccountId = i105FromEd25519AccountId(secondAccountIdRaw);
  withNativeBinding(
    {
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x07]),
          hash: Buffer.alloc(32, 0x88),
        };
      },
    },
    () =>
      buildRegisterAccountAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        account: {
          accountId: NEW_ACCOUNT_ID_INPUT,
        },
        transfers: [
          { sourceAssetId: ASSET_ID, quantity: "2", destinationAccountId: NEW_ACCOUNT_ID_INPUT },
          { sourceAssetId: ASSET_ID, quantity: "1", destinationAccountId: secondAccountIdRaw },
        ],
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [{ instructions }] = captures;
  assert.equal(instructions.length, 3);
  assert.deepEqual(instructions[0].Register.Account.id, NEW_ACCOUNT_ID);
  assert.deepEqual(instructions[0].Register.Account.opaque_ids, []);
  assert.deepEqual(instructions[1], {
    Transfer: {
      Asset: {
        source: ASSET_ID,
        object: "2",
        destination: NEW_ACCOUNT_ID,
      },
    },
  });
  assert.deepEqual(instructions[2], {
    Transfer: {
      Asset: {
        source: ASSET_ID,
        object: "1",
        destination: secondAccountId,
      },
    },
  });
});

test("buildRegisterAccountAndTransferTransaction rejects both transfer and transfers", () => {
  assert.throws(
    () =>
      buildRegisterAccountAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        account: {
          accountId: NEW_ACCOUNT_ID_INPUT,
        },
        transfer: { sourceAssetId: ASSET_ID, quantity: "1", destinationAccountId: NEW_ACCOUNT_ID_INPUT },
        transfers: [],
        privateKey: PRIVATE_KEY,
      }),
    /provide either transfer or transfers/i,
  );
});

test("buildRegisterAccountAndTransferTransaction enforces sourceAssetId in transfers", () => {
  assert.throws(
    () =>
      buildRegisterAccountAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        account: {
          accountId: NEW_ACCOUNT_ID_INPUT,
        },
        transfers: [{ quantity: "1", destinationAccountId: NEW_ACCOUNT_ID_INPUT }],
        privateKey: PRIVATE_KEY,
      }),
    /transfers\[0\]\.sourceAssetId is required/i,
  );
});

test("buildRegisterAssetDefinitionAndMintTransaction expands definition and mint", () => {
  const captures = [];
  withNativeBinding(
    {
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x04]),
          hash: Buffer.alloc(32, 0x55),
        };
      },
    },
    () =>
      buildRegisterAssetDefinitionAndMintTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: {
          assetDefinitionId: ASSET_DEFINITION_ID,
          metadata: { description: "Rose asset" },
          mintable: "Not",
          spec: { scale: 4 },
          confidentialPolicy: {
            vk_set_hash: "deadbeef",
            pending_transition: { stage: "Queued" },
          },
        },
        mint: {
          accountId: NEW_ACCOUNT_ID_INPUT,
          assetId: SECOND_CANONICAL_ASSET_ID_INPUT,
          quantity: "9",
        },
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [{ instructions }] = captures;
  assert.equal(instructions.length, 2);
  assert.deepEqual(instructions[0], {
    Register: {
      AssetDefinition: {
        id: ASSET_DEFINITION_ID,
        logo: null,
        metadata: { description: "Rose asset" },
        mintable: "Not",
        spec: { scale: 4 },
        confidential_policy: {
          mode: "TransparentOnly",
          vk_set_hash: "deadbeef",
          poseidon_params_id: null,
          pedersen_params_id: null,
          pending_transition: { stage: "Queued" },
        },
      },
    },
  });
  assert.deepEqual(instructions[1], {
    Mint: {
      Asset: {
        object: "9",
        destination: SECOND_CANONICAL_ASSET_ID_INPUT,
      },
    },
  });
});

test("buildRegisterAssetDefinitionAndMintTransaction supports mint arrays", () => {
  const captures = [];
  withNativeBinding(
    {
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x08]),
          hash: Buffer.alloc(32, 0x77),
        };
      },
    },
    () =>
      buildRegisterAssetDefinitionAndMintTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: { assetDefinitionId: ASSET_DEFINITION_ID },
        mints: [
          { accountId: NEW_ACCOUNT_ID_INPUT, quantity: "4" },
          { assetId: CANONICAL_ASSET_ID_INPUT, quantity: "2" },
        ],
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [{ instructions }] = captures;
  assert.equal(instructions.length, 3);
  assert.deepEqual(instructions[1], {
    Mint: {
      Asset: {
        object: "4",
        destination: SECOND_CANONICAL_ASSET_ID_INPUT,
      },
    },
  });
  assert.deepEqual(instructions[2], {
    Mint: {
      Asset: {
        object: "2",
        destination: CANONICAL_ASSET_ID_INPUT,
      },
    },
  });
});

test("buildRegisterAssetDefinitionAndMintTransaction rejects both mint and mints", () => {
  assert.throws(
    () =>
      buildRegisterAssetDefinitionAndMintTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: { assetDefinitionId: ASSET_DEFINITION_ID },
        mint: { accountId: NEW_ACCOUNT_ID_INPUT, quantity: "1" },
        mints: [],
        privateKey: PRIVATE_KEY,
      }),
    /provide either mint or mints/i,
  );
});

test("buildRegisterAssetDefinitionAndMintTransaction enforces mint destination fields", () => {
  assert.throws(
    () =>
      buildRegisterAssetDefinitionAndMintTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: { assetDefinitionId: ASSET_DEFINITION_ID },
        mints: [{ quantity: "1" }],
        privateKey: PRIVATE_KEY,
      }),
    /mints\[0\].*assetId.*accountId/i,
  );
});

test("buildRegisterAssetDefinitionAndMintTransaction rejects mismatched assetId/accountId", () => {
  assert.throws(
    () =>
      buildRegisterAssetDefinitionAndMintTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: { assetDefinitionId: ASSET_DEFINITION_ID },
        mints: [
          {
            accountId: NEW_ACCOUNT_ID_INPUT,
            assetId: CANONICAL_ASSET_ID_INPUT,
            quantity: "1",
          },
        ],
        privateKey: PRIVATE_KEY,
      }),
    /must match/,
  );
});

test("buildRegisterAssetDefinitionMintAndTransferTransaction expands definition, mint, and transfer", () => {
  const captures = [];
  withNativeBinding(
    {
      encodeAssetId: encodeAssetIdForKnownAccount,
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x05]),
          hash: Buffer.alloc(32, 0x66),
        };
      },
    },
    () =>
      buildRegisterAssetDefinitionMintAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: { assetDefinitionId: ASSET_DEFINITION_ID },
        mint: { accountId: NEW_ACCOUNT_ID_INPUT, quantity: "5" },
        transfer: { destinationAccountId: AUTHORITY_ID_INPUT, quantity: "2" },
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [{ instructions }] = captures;
  assert.equal(instructions.length, 3);
  assert.deepEqual(instructions[0].Register.AssetDefinition.id, ASSET_DEFINITION_ID);
  assert.deepEqual(instructions[1], {
    Mint: {
      Asset: {
        destination: SECOND_CANONICAL_ASSET_ID_INPUT,
        object: "5",
      },
    },
  });
  assert.deepEqual(instructions[2], {
    Transfer: {
      Asset: {
        source: SECOND_CANONICAL_ASSET_ID_INPUT,
        object: "2",
        destination: AUTHORITY_ID,
      },
    },
  });
});

test("buildRegisterAssetDefinitionMintAndTransferTransaction supports transfer arrays", () => {
  const captures = [];
  const secondAccountIdRaw = AccountAddress.fromAccount({
    publicKey: Buffer.from(ed25519.getPublicKey(Buffer.alloc(32, 0x44))),
  }).toI105();
  const secondAccountId = i105FromEd25519AccountId(secondAccountIdRaw);
  const secondAccountIdInput = i105FromEd25519AccountId(secondAccountIdRaw);
  withNativeBinding(
    {
      encodeAssetId: encodeAssetIdForKnownAccount,
      buildTransaction: (_chain, authority, instructions) => {
        captures.push({ authority, instructions: instructions.map((j) => JSON.parse(j)) });
        return {
          signed_transaction: Buffer.from([0x06]),
          hash: Buffer.alloc(32, 0x77),
        };
      },
    },
    () =>
      buildRegisterAssetDefinitionMintAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: { assetDefinitionId: ASSET_DEFINITION_ID },
        mints: [
          { accountId: NEW_ACCOUNT_ID_INPUT, quantity: "6" },
          { assetId: CANONICAL_ASSET_ID_INPUT, quantity: "1" },
        ],
        transfers: [
          { quantity: "4", destinationAccountId: AUTHORITY_ID_INPUT },
          {
            sourceAssetId: CANONICAL_ASSET_ID_INPUT,
            destinationAccountId: secondAccountIdInput,
            quantity: "1",
          },
        ],
        privateKey: PRIVATE_KEY,
      }),
  );
  assert.equal(captures.length, 1);
  const [{ instructions }] = captures;
  assert.equal(instructions.length, 5);
  assert.deepEqual(instructions[3], {
    Transfer: {
      Asset: {
        source: SECOND_CANONICAL_ASSET_ID_INPUT,
        object: "4",
        destination: AUTHORITY_ID,
      },
    },
  });
  assert.deepEqual(instructions[4], {
    Transfer: {
      Asset: {
        source: CANONICAL_ASSET_ID_INPUT,
        object: "1",
        destination: secondAccountId,
      },
    },
  });
});

test("buildRegisterAssetDefinitionMintAndTransferTransaction rejects both transfer and transfers", () => {
  assert.throws(
    () =>
      buildRegisterAssetDefinitionMintAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: { assetDefinitionId: ASSET_DEFINITION_ID },
        mint: { accountId: NEW_ACCOUNT_ID_INPUT, quantity: "3" },
        transfer: { destinationAccountId: AUTHORITY_ID_INPUT, quantity: "2" },
        transfers: [],
        privateKey: PRIVATE_KEY,
      }),
    /provide either transfer or transfers/i,
  );
});

test("buildRegisterAssetDefinitionMintAndTransferTransaction rejects both mint and mints", () => {
  assert.throws(
    () =>
      buildRegisterAssetDefinitionMintAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: { assetDefinitionId: ASSET_DEFINITION_ID },
        mint: { accountId: NEW_ACCOUNT_ID_INPUT, quantity: "2" },
        mints: [],
        transfers: [{ quantity: "1", destinationAccountId: AUTHORITY_ID_INPUT }],
        privateKey: PRIVATE_KEY,
      }),
    /provide either mint or mints/i,
  );
});

test("buildRegisterAssetDefinitionMintAndTransferTransaction requires mint spec", () => {
  assert.throws(
    () =>
      buildRegisterAssetDefinitionMintAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: { assetDefinitionId: ASSET_DEFINITION_ID },
        transfers: [{ quantity: "1", destinationAccountId: AUTHORITY_ID_INPUT }],
        privateKey: PRIVATE_KEY,
      }),
    /mint or mints parameters are required/i,
  );
});

test("buildRegisterAssetDefinitionMintAndTransferTransaction validates mint destination", () => {
  assert.throws(
    () =>
      buildRegisterAssetDefinitionMintAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: { assetDefinitionId: ASSET_DEFINITION_ID },
        mints: [{ quantity: "1" }],
        transfers: [{ quantity: "1", destinationAccountId: AUTHORITY_ID_INPUT }],
        privateKey: PRIVATE_KEY,
      }),
    /mints\[0\].*assetId.*accountId/i,
  );
});

test("buildRegisterAssetDefinitionMintAndTransferTransaction rejects mismatched assetId/accountId", () => {
  assert.throws(
    () =>
      buildRegisterAssetDefinitionMintAndTransferTransaction({
        chainId: "test-chain",
        authority: AUTHORITY_ID_INPUT,
        assetDefinition: { assetDefinitionId: ASSET_DEFINITION_ID },
        mints: [
          {
            accountId: NEW_ACCOUNT_ID_INPUT,
            assetId: CANONICAL_ASSET_ID_INPUT,
            quantity: "1",
          },
        ],
        transfers: [{ quantity: "1", destinationAccountId: AUTHORITY_ID_INPUT }],
        privateKey: PRIVATE_KEY,
      }),
    /must match/,
  );
});

function withNativeBinding(binding, fn) {
  const previous = globalThis.__IROHA_NATIVE_BINDING__;
  globalThis.__IROHA_NATIVE_BINDING__ = binding;
  try {
    return fn();
  } finally {
    globalThis.__IROHA_NATIVE_BINDING__ = previous;
  }
}

function createResponse({ status, jsonData = {}, arrayData, textBody, headers }) {
  let body;
  if (arrayData instanceof ArrayBuffer) {
    body = arrayData;
  } else if (ArrayBuffer.isView(arrayData)) {
    body = new Uint8Array(
      arrayData.buffer,
      arrayData.byteOffset,
      arrayData.byteLength,
    );
  } else {
    body =
      typeof textBody === "string" ? textBody : JSON.stringify(jsonData ?? {});
  }
  return new Response(body, { status, headers });
}
